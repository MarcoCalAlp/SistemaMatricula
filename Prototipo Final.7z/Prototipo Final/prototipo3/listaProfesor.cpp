/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   listaProfesor.cpp
 * Author: Johan
 * 
 * Created on 14 de junio de 2017, 11:41 PM
 */

#include "listaProfesor.h"

listaProfesor::listaProfesor():lista<profesor>() {
}

listaProfesor::~listaProfesor() {
    
}
//metodos relacionado con archivos

listaProfesor::listaProfesor(ifstream &entrada):lista<profesor>() {
	deserialize(entrada, this);
}

bool listaProfesor::guardar(ofstream &salida) {
      return   serialize(salida, (listaProfesor*)this);
}

//Este método lee la información del clientes que esta en el archivo
//y llama al constructor de cliente

void listaProfesor::deserialize(ifstream &entrada, listaProfesor* g) {
	int can = -1;
	int i = 0;
	entrada.read((char*)&can, sizeof(can));

	while(entrada.good() && i < can) {
		try {
			profesor* objeto = NULL;

			if(!entrada.good())
				break;

			objeto = new profesor(entrada);

			if(objeto!= NULL)
				g->agregarFinal(objeto); 
		}
		catch(int) {
		}
		i++;
	}
}

//Retorna el total objetos almacenados

int listaProfesor::totalObjetos() const{
	int can = 0;
        iterador<profesor>* i = this->obtenerIterador();
	
	while(i->masElementos()) {

		profesor* objeto= (profesor*)i->proximoElemento();

		if (objeto != NULL){
			can++;
		}
             
	}
	return can;
}

//Este método serializa(guarda) la informacion del cliente

bool listaProfesor::serialize(ofstream &salida, listaProfesor* g) {
	int can = 0;
	iterador<profesor>* i = g->obtenerIterador();
	can = g->totalObjetos();
	salida.write((char*)&can,sizeof(can));
	while(i->masElementos() && salida.good()) {

		profesor* objeto= (profesor*)i->proximoElemento();

		objeto->guardar(salida);
	}
        return salida.good();
     
}
