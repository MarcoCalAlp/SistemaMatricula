/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   estudiante.cpp
 * Author: Johan
 * 
 * Created on 1 de mayo de 2017, 08:35 PM
 */

#include "estudiante.h"

estudiante::estudiante(string nom,string ap ,string id, string ct, string nac,int beca) :  nombre(nom), apellidos(ap), cedula(id), carnet(ct), nacionalidad(nac),porcentaje(beca) {
   

}
estudiante::estudiante()
{
    nombre=" ";
    apellidos=" ";
    cedula= " ";
    carnet=" ";
    nacionalidad=" ";
    porcentaje=0;

}
string estudiante::obtenerNombre() {
    return this->nombre;
}

string estudiante::obtenerCedula() {
    return this->cedula;
}

string estudiante::obetenerCarnet() {
    return this->carnet;
}

string estudiante::obtenerApellidos() {
    return this->apellidos;
}

string estudiante::obtenerNacionalidad() {
    return this->nacionalidad;
}

int estudiante::obtenerPorcentaje() {
    return this->porcentaje;
}

void estudiante::establecerNombre(string nom) {
    this->nombre = nom;
}

void estudiante::establecerApellidos(string ap) {
    this->apellidos = ap;
}

void estudiante::establecerNacionalidad(string nac) {
    this->nacionalidad = nac;
    if(nacionalidad!="Costarricense"||nacionalidad!="costarricense"||nacionalidad!="COSTARRICENSE"){
        establecerPcBeca(0);
    }
}
void estudiante::establecerPcBeca(int beca)
{
    porcentaje=beca;
}
void estudiante::establecerCedula(string id)
{
    cedula=id;
}
void estudiante::establecerCarnet(string c)
{
    carnet=c;
}
 string estudiante::imprime() {
    stringstream s;
    s << "Nombre: " << nombre << endl;
    s << "Apellidos: " << apellidos << endl;
    s << "Cedula: " << cedula << endl;
    s << "Carnet: " << carnet << endl;
    s << "Nacionalidad: " << nacionalidad << endl;
    s << "Categoria de beca: " << porcentaje << endl;
    return s.str();
}

estudiante::~estudiante() {
}
//metodos relacionados con archivos 
estudiante::estudiante(ifstream& entrada){
    deserialize(entrada, this);
}
bool estudiante::guardar(ofstream& salida){
 return serialize(salida, (estudiante*)this);
}
void estudiante::deserialize(ifstream& entrada, estudiante* est) {
    est->nombre = sstring::deserialize(entrada);
    est->apellidos = sstring::deserialize(entrada);
    est->cedula = sstring::deserialize(entrada);
    est->carnet = sstring::deserialize(entrada);
    est->nacionalidad = sstring::deserialize(entrada);
    entrada.read((char*) &est->porcentaje, sizeof (est->porcentaje));
    if (!entrada.good())
        throw -1;
}

bool estudiante::serialize(ofstream &salida, estudiante* est) {
    sstring::serialize(salida, est->nombre);
    sstring::serialize(salida, est->apellidos);
    sstring::serialize(salida, est->cedula);
    sstring::serialize(salida, est->carnet);
    sstring::serialize(salida, est->nacionalidad);
    salida.write((char*) &est->porcentaje, sizeof (est->porcentaje));
    return salida.good();
}