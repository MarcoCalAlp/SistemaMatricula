/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   entero.h
 *
 * Created on May 3, 2017, 7:56 AM
 */

#ifndef ENTERO_H
#define ENTERO_H

#include <sstream>
using namespace std;

class entero {
public:
    entero(int=0);
    virtual ~entero();
    virtual string toString() const;
private:
    int valor;

};

#endif /* ENTERO_H */

