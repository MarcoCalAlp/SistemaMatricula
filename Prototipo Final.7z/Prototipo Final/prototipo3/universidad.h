/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   universidad.h
 * Author: marcovinicio
 *
 * Created on 9 de marzo de 2017, 07:28 PM
 */

#ifndef UNIVERSIDAD_H
#define UNIVERSIDAD_H

#include "matricula.h"

#include "listaEscuela.h"
#include "listaEstudiante.h"

class universidad {
public:
    //METODOS RELACIONADOS CON UNIVERSIDAD
    universidad();
    universidad(string,string,int);
    virtual void estNombre(string) ;
    virtual string imprimeDatos();
    virtual void estDireccion(string);
    virtual void estTelefono(int);
    virtual string obtNombre();
    virtual string obtDireccion();
    virtual int obtTelefono();
    virtual string imprimeRecuperar();
    //METODOS RELACIONADOS CON ESCUELAS
    virtual void registraEscuelas();
    virtual void muestraEscuelas();
    //METODOS RELACIONADOS CON CURSOS
    virtual void incluCursosU();
    virtual void verCursos();
    virtual void borrarCursos();
    virtual void verCursosTotal();
    virtual void modificarCurso();
    virtual void datosCurso(); 
    //METODOS RELACIONADOS CON PROFESORES
    virtual void incluProf();
    virtual void verProf();
    virtual void modificarProf();
    virtual void datosProf();
    virtual void asignaProfCurso();
    virtual void verProfYCur();
    virtual void deasignaProfCurso();
    virtual void escuelaDirector();
    virtual void soloProfYcur();
    virtual void cargaAcademicaU();
    virtual void recuperarArcProf(string,ifstream&);
    virtual void guardarArcProf(string,ofstream&);
    //METODOS RELACIONADOS CON ESTUDIANTES
    virtual void incluirEst();
    virtual void modificarEst();
    virtual void modNombreEst();
    virtual void modApellidosEst();
    virtual void modNacionalidadEst();
    virtual void buscarEstudiante();
    virtual void buscarEstID();
    virtual void buscarEstCarnet();
    virtual void matricular();
    virtual void desasignarEst();
    virtual void mostrarEstYCurso();
    virtual void mostrarCursosEstudiante();
    virtual void costoMatricula();
    //Ley de 3
    universidad(const universidad&);
    virtual ~universidad();
    virtual universidad& operator=(const universidad&);
       // metodos relacionados con cursos
    universidad(ifstream&);
    virtual bool guardar(ofstream&);
    static void deserialize(ifstream&, universidad*);
    static bool serialize(ofstream&, universidad*);
private:
    string nombre;
    string direccion;
    int telefono;
    listaEscuela* le;
    iterador<escuela>* ite;
    escuela *e1;
    listaEstudiante* ls;
    iterador<estudiante>* its;
    estudiante *est;
    matricula* m;
};

#endif /* UNIVERSIDAD_H */

