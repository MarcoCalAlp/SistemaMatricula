/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   listaCurso.cpp
 * Author: Johan
 * 
 * Created on 15 de junio de 2017, 12:40 AM
 */

#include "listaCurso.h"

listaCurso::listaCurso():lista<curso>() {
}

listaCurso::~listaCurso() {
}
//metodos relacionado con archivos

listaCurso::listaCurso(ifstream &entrada):lista<curso>() {
	deserialize(entrada, this);
}

bool listaCurso::guardar(ofstream &salida) {
      return   serialize(salida, (listaCurso*)this);
}

//Este método lee la información del clientes que esta en el archivo
//y llama al constructor de cliente

void listaCurso::deserialize(ifstream &entrada, listaCurso* g) {
	int can = -1;
	int i = 0;
	entrada.read((char*)&can, sizeof(can));

	while(entrada.good() && i < can) {
		try {
			curso* objeto = NULL;

			if(!entrada.good())
				break;

			objeto = new curso(entrada);

			if(objeto!= NULL)
				g->agregarFinal(objeto); 
		}
		catch(int) {
		}
		i++;
	}
}

//Retorna el total objetos almacenados

int listaCurso::totalObjetos() const{
	int can = 0;
        iterador<curso>* i = this->obtenerIterador();
	
	while(i->masElementos()) {

		curso* objeto= (curso*)i->proximoElemento();

		if (objeto != NULL){
			can++;
		}
             
	}
	return can;
}

//Este método serializa(guarda) la informacion del cliente

bool listaCurso::serialize(ofstream &salida, listaCurso* g) {
	int can = 0;
	iterador<curso>* i = g->obtenerIterador();
	can = g->totalObjetos();
	salida.write((char*)&can,sizeof(can));
	while(i->masElementos() && salida.good()) {

		curso* objeto= (curso*)i->proximoElemento();

		objeto->guardar(salida);
	}
        return salida.good();
     
}

