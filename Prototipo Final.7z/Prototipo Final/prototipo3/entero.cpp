/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   entero.cpp
 * 
 * Created on May 3, 2017, 7:56 AM
 */

#include "entero.h"

entero::entero(int valor): valor(valor) {
}


entero::~entero() {
}

string entero::toString() const{
    stringstream r;
    r << valor << ",";
    return r.str();
}

