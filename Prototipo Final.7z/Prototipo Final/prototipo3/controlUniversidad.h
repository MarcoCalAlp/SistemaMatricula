/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Interfaz.h
 * Author: marcovinicio
 *
 * Created on 9 de marzo de 2017, 11:45 PM
 */

#ifndef CONTROLUNIVERSIDAD_H
#define CONTROLUNIVERSIDAD_H
#include<iostream>
#include<sstream>
#include"universidad.h"
#include<stdlib.h>
#include<stdio.h>
using namespace std;

class controlUniversidad {
public:
    controlUniversidad();
    virtual ~controlUniversidad();
    virtual int menu();
    virtual void evaluaMenu();
    virtual void guardar();
    virtual void recuperar();
    //-----OPCIONES UNIVERSIDAD
    virtual void ingresaDatosU();
    virtual void actualizaDatosU();
    virtual void ImprimeDatosU();
    //-----OPCIONES ESCUELA
    virtual void Escuelas();
    virtual void impEscuelas();
    //-----OPCIONES CURSOS
    
    virtual void evaluaMenuCursos();
    virtual int  menuCursos();
    virtual void incluyeCursos();
    virtual void modificaCursos();
    virtual void muestraTodosCursos();
    virtual void muestraCursoEspecifico();
    virtual void muestraDatosCurso();
    virtual void borraCursos();
    virtual void soloProfesYcursosAsig();
    //-----OPCIONES PROFESORES
    virtual void evaluaMenuProf();
    virtual int  menuCursosProf();
    virtual void incluye();
    virtual void modifica();
    virtual void muestraProfesEscuela();
    virtual void informacionProfesor();
    virtual void asignacionProfesores();
    virtual void muestraProfesCurso();
    virtual void quitaProfesCurso();
    virtual int menuProfAsigDes();
    virtual void evaluaMenuAsigYDesasig();
    virtual void director();
    virtual void cargaAcademicaI();
    //virtual void recuperaDat();
    //virtual void guardarDat();
    // -----OPCIONES ESTUDIANTES
    virtual int menuCursosEst();
    virtual void evaluaMenuEst();
    virtual void incluyeEst();
    virtual void modificaEst();
    virtual void informacionEst();
    virtual void matricularEst();
    virtual void muestraEstCurso();
    virtual void asignarEst();
    virtual void quitarEstCursos();
    virtual int menuEstAsigYDes();
    virtual void evaluaMenuAsigYDesasigEst();
    virtual void mostrarTotalCurEst();
    virtual void montoTotalDeMatricula();
    ///virtual void incluCursos();*/
    
private:
    universidad*u;

};

#endif /* CONTROLUNIVERSIDAD_H */

