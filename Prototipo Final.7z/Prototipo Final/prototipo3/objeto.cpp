/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   objeto.cpp
* Author: Marco Vinicio y Johan Quesada
 * 
 * Created on 9 de abril de 2017, 01:21 PM
 */

#include "objeto.h"

objeto::objeto() {
}

objeto::~objeto() {
}

