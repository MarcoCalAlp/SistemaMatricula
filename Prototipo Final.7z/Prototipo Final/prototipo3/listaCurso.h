/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   listaCurso.h
 * Author: Johan
 *
 * Created on 15 de junio de 2017, 12:40 AM
 */

#ifndef LISTACURSO_H
#define LISTACURSO_H
#include "lista.h"
#include "std.h"
#include "curso.h"
class listaCurso: public lista<curso>{
public:
    listaCurso();
  
    virtual ~listaCurso();
 //metodos relacionados con archivos 
     listaCurso(ifstream&);
    virtual bool guardar(ofstream&);
    static void deserialize(ifstream&, listaCurso*);
    static bool serialize(ofstream&, listaCurso*);
   virtual  int totalObjetos()const;

};

#endif /* LISTACURSO_H */

