/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   objeto.h
* Author: Marco Vinicio y Johan Quesada
 *
 * Created on 9 de abril de 2017, 01:21 PM
 */

#ifndef OBJETO_H
#define OBJETO_H
#include<iostream>
#include<sstream>
#include <string>
using namespace std;
class objeto {
public:
    objeto();
    virtual string imprime() = 0;
    virtual ~objeto();
private:

};

#endif /* OBJETO_H */

