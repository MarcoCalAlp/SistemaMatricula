/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   listaProfesor.h
 * Author: Johan
 *
 * Created on 14 de junio de 2017, 11:41 PM
 */

#ifndef LISTAPROFESOR_H
#define LISTAPROFESOR_H
#include "lista.h"
#include "std.h"
#include "profesor.h"
class listaProfesor:public lista<profesor> {
public:
    listaProfesor();
    virtual ~listaProfesor();
    
    //metodos relacionados con archivos 
     listaProfesor(ifstream&);
    virtual bool guardar(ofstream&);
    static void deserialize(ifstream&, listaProfesor*);
    static bool serialize(ofstream&, listaProfesor*);
   virtual  int totalObjetos()const;

};

#endif /* LISTAPROFESOR_H */

