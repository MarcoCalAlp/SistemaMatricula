/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   escuela.h
 * Author: marcovinicio
 *
 * Created on 9 de marzo de 2017, 07:29 PM
 */

#ifndef ESCUELA_H
#define ESCUELA_H
//#include<iostream>
//#include <sstream>
//#include "lista.h"
//#include "iterador.h"
//#include "iteradorLista.h"
//#include "profesor.h"
//#include "curso.h"
#include "listaProfesor.h"
#include "listaCurso.h"


class escuela  {
public:
    //ESCUELAS
    escuela();
    escuela(string);
    void estNombre(string);
    string obtNombre();
    virtual string imprime();
    //CURSOS
    virtual void ingresaCursos();
    virtual void modificaCursoSigla();
    virtual void modificaCursoNombre();
    virtual void muestraCursos();
    virtual void eliminaCursos();
    virtual void imprimeCurYesc();
    virtual void informacionCurso();
    virtual curso* retornaCur();
    //PROFES 
    
    virtual profesor* ingresaProf();
    virtual void asigna();
    virtual void desasigna();
    virtual void muestraProfes();
    virtual void informacionProf();
    virtual void modificaNombreProf();
    virtual void modificaApellidoIProf();
    virtual void modificaApellidoIIProf();
    virtual void muestraProfPorCur();
    virtual void asignaDirector();
    virtual void ambosPyC();
    virtual void cargaAcademica();
    virtual void guardaProfA(string,ofstream&);
    virtual void recuperaProfA(string,ifstream&);
    //Estudiantes
     virtual void matricularEstu(lista<estudiante>* );
     virtual void imprimirCursoPorEstudiante(estudiante* );
     virtual int totalCreditosCurso(estudiante*);
    //Ley de 3
    virtual escuela& operator=(const escuela&);
    virtual ~escuela();
    escuela(const escuela&);
    
    
    // metodos relacionados con cursos
    escuela(ifstream&);
    virtual bool guardar(ofstream&);
    static void deserialize(ifstream&, escuela*);
    static bool serialize(ofstream&, escuela*);
private:
    string nombre;
    listaCurso* lc;
    iterador<curso>* itc;
    listaProfesor* lp2;
    iterador<profesor>* itp2;
    profesor*t;
    curso*c;

};

#endif /* ESCUELA_H */

