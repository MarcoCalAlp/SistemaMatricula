/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   listaEscuela.cpp
 * Author: Johan
 * 
 * Created on 15 de junio de 2017, 12:59 AM
 */

#include "listaEscuela.h"

listaEscuela::listaEscuela():lista<escuela>() {
}

listaEscuela::~listaEscuela() {
}
//metodos relacionado con archivos

listaEscuela::listaEscuela(ifstream &entrada):lista<escuela>() {
	deserialize(entrada, this);
}

bool listaEscuela::guardar(ofstream &salida) {
      return   serialize(salida, (listaEscuela*)this);
}

//Este método lee la información del clientes que esta en el archivo
//y llama al constructor de cliente

void listaEscuela::deserialize(ifstream &entrada, listaEscuela* g) {
	int can = -1;
	int i = 0;
	entrada.read((char*)&can, sizeof(can));

	while(entrada.good() && i < can) {
		try {
			escuela* objeto = NULL;

			if(!entrada.good())
				break;

			objeto = new escuela(entrada);
                        //cout<<objeto->imprime();

			if(objeto!= NULL)
				g->agregarFinal(objeto); 
		}
		catch(int) {
		}
		i++;
                
	}
}

//Retorna el total objetos almacenados

int listaEscuela::totalObjetos() const{
	int can = 0;
        iterador<escuela>* i = this->obtenerIterador();
	
	while(i->masElementos()) {

		escuela* objeto= (escuela*)i->proximoElemento();

		if (objeto != NULL){
			can++;
		}
             
	}
	return can;
}

//Este método serializa(guarda) la informacion del cliente

bool listaEscuela::serialize(ofstream &salida, listaEscuela* g) {
	int can = 0;
	iterador<escuela>* i = g->obtenerIterador();
	can = g->totalObjetos();
	salida.write((char*)&can,sizeof(can));
	while(i->masElementos() && salida.good()) {

		escuela* objeto= (escuela*)i->proximoElemento();

		objeto->guardar(salida);
	}
        return salida.good();
     
}

string listaEscuela::toString() {
	stringstream r;
	iterador<escuela>* i = this->obtenerIterador();
	while(i->masElementos()) {
		escuela* cl= (escuela*)i->proximoElemento();
		r << cl->imprime() << "\n";
	}
	return r.str();
}

