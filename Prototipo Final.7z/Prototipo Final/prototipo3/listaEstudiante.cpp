/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   listaEstudiante.cpp
 * Author: Johan
 * 
 * Created on 15 de junio de 2017, 12:26 AM
 */

#include "listaEstudiante.h"

listaEstudiante::listaEstudiante():lista<estudiante>() {
}

listaEstudiante::~listaEstudiante() {
    
}
//metodos relacionado con archivos

listaEstudiante::listaEstudiante(ifstream &entrada):lista<estudiante>() {
	deserialize(entrada, this);
}

bool listaEstudiante::guardar(ofstream &salida) {
      return   serialize(salida, (listaEstudiante*)this);
}

//Este método lee la información del clientes que esta en el archivo
//y llama al constructor de cliente

void listaEstudiante::deserialize(ifstream &entrada, listaEstudiante* g) {
	int can = -1;
	int i = 0;
	entrada.read((char*)&can, sizeof(can));

	while(entrada.good() && i < can) {
		try {
			estudiante* objeto = NULL;

			if(!entrada.good())
				break;

			objeto = new estudiante(entrada);
                        //cout<<objeto->imprime();

			if(objeto!= NULL)
				g->agregarFinal(objeto); 
		}
		catch(int) {
		}
		i++;
	}
}

//Retorna el total objetos almacenados

int listaEstudiante::totalObjetos() const{
	int can = 0;
     iterador<estudiante>* i = this->obtenerIterador();
	
	while(i->masElementos()) {

		estudiante* objeto= (estudiante*)i->proximoElemento();

		if (objeto != NULL){
			can++;
		}
             
	}
	return can;
}

//Este método serializa(guarda) la informacion del cliente

bool listaEstudiante::serialize(ofstream &salida, listaEstudiante* g) {
	int can = 0;
	iterador<estudiante>* i = g->obtenerIterador();
	can = g->totalObjetos();
	salida.write((char*)&can,sizeof(can));
	while(i->masElementos() && salida.good()) {

		estudiante* objeto= (estudiante*)i->proximoElemento();

		objeto->guardar(salida);
	}
        return salida.good();
     
}
//----------------------------------------------------------------------
string listaEstudiante::toString() {
	stringstream r;
	iterador<estudiante>* i = this->obtenerIterador();
	while(i->masElementos()) {
		estudiante* cl= (estudiante*)i->proximoElemento();
		r << cl->imprime() << "\n";
	}
	return r.str();
}


