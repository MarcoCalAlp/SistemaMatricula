/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Interfaz.cpp
 * Author: marcovinicio y johan
 * 
 * Created on 9 de marzo de 2017, 11:45 PM
 */

#include "controlUniversidad.h"

controlUniversidad::controlUniversidad() {
    u=new universidad();
}

//----------------------Metodos implementados en el menu principal-------------
 void controlUniversidad::Escuelas(){
    int q; char sNum[20];
    cout<<"Digite la cantidad de escuelas que desea ingresar"<<endl;
    cin>>sNum;
    q=atoi(sNum);
     if(q!=0){ 
        for(int i=0;i<q;i++)
        u->registraEscuelas();
     }
     else{
         cout<<"!!!Error , se necesita digitar un numero"<<endl;
         Escuelas();
    }
         
 }
 //----------------------------------------------------------------------------
 void controlUniversidad::impEscuelas(){
     cout<<"--------------Universidad:"<<u->obtNombre();cout<<endl;
     u->muestraEscuelas();
 }
 //----------------------------------------------------------------------------
void controlUniversidad::ingresaDatosU(){
    string nom,dir;
    int num;
    char sNum[20];
    if(u->obtNombre()== "")
    {
        cout<<"----Digite el Nombre de la universidad------"<<endl;
        cin>>nom;
        u->estNombre(nom);
    }
    else 
    {
        cout<<"--------------Universidad:"<<u->obtNombre();cout<<endl;
        cout<<"!!!El nombre de la universidad no se puede modificar!!!"<<endl;
    }
    cout<<"---------Digite  la direccion de la universidad-----"<<endl;
    cin>>dir;
    u->estDireccion(dir);
    cout<<"---------Digite  el numero telefonico de la universidad-----"<<endl;
    cin>>sNum;
    num=atoi(sNum);
    if(num!=0){ 
     u->estTelefono(num);   
     }
    else{
     cout<<"!!!Error , se necesita digitar un numero"<<endl;
    }
   
}
//--------------------------------------------------------------------
void controlUniversidad::actualizaDatosU(){
    string dir;
    int num;
    char sNum[20];
    cout<<"--------------Universidad:"<<u->obtNombre();cout<<endl;
    cout<<"------------------------------------------------------------"<<endl;
    cout<<"---------Digite  la nueva direccion de la universidad-----"<<endl;
    cin>>dir;
    u->estDireccion(dir);
    cout<<"---------Digite  el nuevo numero telefonico de la universidad-----"<<endl;
    cin>>sNum;
    num=atoi(sNum);
    if(num!=0){ 
     u->estTelefono(num);   
     }
    else{
     cout<<"!!!Error , se necesita digitar un numero"<<endl;
    }
}
//----------------------------------------------------------------------------
 void controlUniversidad::ImprimeDatosU(){
   cout<<  u->imprimeDatos();
 }
 //---------------------------------------------------------------------------
  void controlUniversidad:: guardar(){
    string archivo;
    cout<<"Digite el nombre del archivo donde sea desea guardar seguido de la extension"<<endl;
    cin>>archivo;
    //string archivo = "universidad.txt";
    ofstream salida(archivo.c_str()); 
    u->guardar(salida);
    //u->guardarArcProf(archivo,salida);
    salida.close();
    cout<<"Guardando . . ."<<endl;
     
  }
//---------------------------------------------------------------------------
  void controlUniversidad:: recuperar(){
      string archivo;
        cout<<"Digite el nombre del archivo donde sea recuperar los datos seguido de la extension"<<endl;
        cin>>archivo;
      //string archivo = "universidad.txt";
      ifstream entrada(archivo.c_str());
      universidad* un = new universidad(entrada);
      //cout<<"Recuperando . . ."<<endl;
     // u->recuperarArcProf(archivo,entrada);
      entrada.close();
     // u->recuperarArcProf(archivo,entrada);
      //cout<<"Recuperando . . ."<<endl;
      //u->recuperarArcProf(archivo,entrada);
      cout<<u->imprimeDatos();
      
  }
 //-----------------------------Menu Principal---------------------------------
int controlUniversidad :: menu(){
	int opciones =0;
        char sNum[20];
	//system("color 0F");
	cout << "      ____________________________________________________________________       " << endl;
	cout << "     |                                                                    |      " << endl;
	cout << "     |                            -Bienvenido-                            |      " << endl;
	cout << "     |                                                                    |      " << endl;
	cout << "     |                       -Sistema de Matricula-                       |      " << endl;
	cout << "     |                                                                    |      " << endl;
	cout << "     |____________________________________________________________________|      " << endl;
	cout << "     |      - Presione [1] para ingresar los datos de la universidad      |      " << endl;
	cout << "     |      - Presione [2] para actualizar los datos de la universidad    |      " << endl;
	cout << "     |      - Presione [3] para registrar escuelas                        |      " << endl;
	cout << "     |      - Presione [4] para consulta de las escuelas                  |      " << endl;
	cout << "     |      - Presione [5] para ver datos de la universidad               |      " << endl;
        cout << "     |      - Presione [6] para ir al menu de cursos                      |      " << endl;
        cout << "     |      - Presione [7] para ir al menu de profesores                  |      " << endl;
        cout << "     |      - Presione [8] para ir al menu de estudiantes                 |      " << endl;
        cout << "     |      - Presione [9] guardar U                                      |      " << endl;
        cout << "     |      - Presione [10] recuperar U                                   |      " << endl;
        cout << "     |      - Presione [11] para salir                                    |      " << endl;
	cout << "     |____________________________________________________________________|      " << endl;
	cin >> sNum;
        opciones=atoi(sNum);
        if(opciones!=0){  
            return opciones;
        }
        else{
         cout<<"!!!Error , se necesita digitar un numero"<<endl;
         evaluaMenu();
        }
}
//------------------------------------------------------------------------------
void controlUniversidad :: evaluaMenu(){
	int opciones = 0;
	do{
	opciones = menu();
	switch(opciones){
	case 1: ingresaDatosU();
		break;

	case 2:
                actualizaDatosU();
		break;
		   
	case 3:  Escuelas();
                //system("cmd /c cls");
                //system("cmd /c cls");
		break;

	case 4: impEscuelas(); 
		break;
        case 5: ImprimeDatosU();
		break;
	case 6: evaluaMenuCursos();
		break;
        case 7: evaluaMenuProf();
        case 8: evaluaMenuEst();
        case 9:guardar();
        case 10:recuperar();
        case 11:
                getchar();
		  exit(0);
		break;

	default:
		cout << "Error" << endl; 
                evaluaMenu();
	}
	} while(opciones != 12 && opciones != 0);
}

//--------------------------SubMenu de Cursos----------------------------------
int controlUniversidad :: menuCursos(){
    //Para ver los metodos mostrar con profesores incluidos , se tiene que insertar 
    //primero los profes y despues asignarselo a algun curso.Todo esto en el submenu 
    //de profesores.
	int opciones =0;
        char sNum[20];
	//system("color 0F");
	cout << "      ____________________________________________________________________       " << endl;
	cout << "     |                                                                    |      " << endl;
	cout << "     |                       Submenu de cursos                            |      " << endl;
	cout << "     |                                                                    |      " << endl;
	cout << "     |                       -Sistema de Matricula-                       |      " << endl;
	cout << "     |                                                                    |      " << endl;
	cout << "     |____________________________________________________________________|      " << endl;
	cout << "     |      - Presione [1] para ingresar los cursos                       |      " << endl;
	cout << "     |      -Presione  [2] para mostrar los datos de un curso             |      " << endl;
	cout << "     |      - Presione [3] para mostrar los cursos de una escuela         |      " << endl;
	cout << "     |  - Presione [4] para mostrar todos los cursos(Escuelas,Profesores) |      " << endl;
	cout << "     |      - Presione [8] para modificar un curso                        |      " << endl;
        cout << "     |      - Presione [6] para eliminar un curso                         |      " << endl;
        cout << "     |      - Presione [7] para ver cursos solamente con profesores       |      " << endl;
	cout << "     |      - Presione [9] para volver al menu principal                  |      " << endl;
        cout << "     |____________________________________________________________________|      " << endl;
	cin >> sNum;
        opciones=atoi(sNum);
        if(opciones!=0){  
            return opciones;
        }
        else{
         cout<<"!!!Error , se necesita digitar un numero"<<endl;
         evaluaMenuCursos();
        }
}
//-----------------------------------------------------------------------------
void controlUniversidad :: evaluaMenuCursos(){
	int opciones = 0;
	do{
	opciones = menuCursos();
	switch(opciones){
	case 1:incluyeCursos() ;
		break;

	case 2:muestraDatosCurso();
		break;
		   
	case 3:muestraCursoEspecifico(); 
		break;

	case 4:muestraTodosCursos();
		break;
        case 8:modificaCursos();
		break;
	case 6:borraCursos();
		break;
        case 7:soloProfesYcursosAsig();
        case 9:    
                evaluaMenu();
                getchar();
		exit(0);
		break;

	default:
		cout << "Error" << endl; 
                evaluaMenuCursos();
	}
	} while(opciones != 10 && opciones != 0);
}

//---------------------Metodos implementados en el submenu de cursos-----------
void controlUniversidad  :: incluyeCursos(){u->incluCursosU();}
void controlUniversidad :: modificaCursos(){u->modificarCurso();}
void controlUniversidad  :: muestraTodosCursos(){u->verCursosTotal();}
void controlUniversidad :: muestraCursoEspecifico(){u->verCursos();}
void controlUniversidad :: muestraDatosCurso(){ u->datosCurso();}
void controlUniversidad :: borraCursos(){u->borrarCursos();}
void controlUniversidad ::soloProfesYcursosAsig(){u->soloProfYcur();}


 
//-------------------------------Submenu Profesores----------------------------------------------
int controlUniversidad  :: menuCursosProf(){
	int opciones =0;
        char sNum[20];
	//system("color 0F");
	cout << "      ____________________________________________________________________       " << endl;
	cout << "     |                                                                    |      " << endl;
	cout << "     |                       Submenu de Profesores                        |      " << endl;
	cout << "     |                                                                    |      " << endl;
	cout << "     |                       -Sistema de Matricula-                       |      " << endl;
	cout << "     |                                                                    |      " << endl;
	cout << "     |____________________________________________________________________|      " << endl;
	cout << "     |      - Presione [1] para ingresar profesores                       |      " << endl;
        cout << "     |      - Presione [2] para asignar director                          |      " << endl;
	cout << "     |      - Presione [3] para modificar los datos de un profesor        |      " << endl;
	cout << "     |      - Presione [4] para mostrar los datos de un profesor          |      " << endl;
	cout << "     |      - Presione [8] para mostrar profesores segun escuela          |      " << endl;
	cout << "     |      - Presione [6] para asignar o desasignar profesores a cursos  |      " << endl;
        cout << "     |      - Presione [7] mostrar cursos de un profesor                  |      " << endl;
	cout << "     |      - Presione [9] mostrar profesores de un curso determinado     |      " << endl;
        cout << "     |      - Presione [10] guardar                                       |      " << endl;
        cout << "     |      - Presione [11] recuperar                                     |      " << endl;
        cout << "     |      - Presione [12] para volver al menu principal                 |      " << endl;
        cout << "     |____________________________________________________________________|      " << endl;
	cin >> sNum;
        opciones=atoi(sNum);
        if(opciones!=0){  
            return opciones;
        }
        else{
         cout<<"!!!Error , se necesita digitar un numero"<<endl;
         evaluaMenuProf();
        }
}
//-----------------------------------------------------------------------------
void controlUniversidad :: evaluaMenuProf(){
	int opciones = 0;
	do{
	opciones = menuCursosProf();
	switch(opciones){
	case 1:incluye();
		break;

	case 2:director();           
		break;
		   
	case 3:modifica();                     
		break;

	case 4:informacionProfesor();                       
		break;
        case 8: muestraProfesEscuela();                                      
		break;
	case 6:evaluaMenuAsigYDesasig();
		break;
        case 7:cargaAcademicaI();
                break;
        case 9:muestraProfesCurso();
        case 10://guardarDat();
        case 11://recuperaDat();
        case 12:evaluaMenu();
                getchar();
		exit(0);
		break;

	default:
		cout << "Error" << endl; 
                evaluaMenuCursos();
	}
	} while(opciones != 13 && opciones != 0);
}
//-----------------------------------------------------------------------------
int controlUniversidad  :: menuProfAsigDes(){
	int opciones =0;
        char sNum[20];
	//system("color 0F");
	cout << "      ____________________________________________________________________       " << endl;
	cout << "     |                                                                    |      " << endl;
	cout << "     |                       Submenu de Profesores                        |      " << endl;
	cout << "     |                                                                    |      " << endl;
	cout << "     |                       -Sistema de Matricula-                       |      " << endl;
	cout << "     |                                                                    |      " << endl;
	cout << "     |____________________________________________________________________|      " << endl;
	cout << "     |      - Presione [1] para asignar profesores a cursos               |      " << endl;
	cout << "     |      - Presione [2] para desasignar profesores a cursos            |      " << endl;
        cout << "     |      - Presione [3] para regresar al menu de profesores            |      " << endl;
        cout << "     |____________________________________________________________________|      " << endl;
	cin >> sNum;
        opciones=atoi(sNum);
        if(opciones!=0){  
            return opciones;
        }
        else{
         cout<<"!!!Error , se necesita digitar un numero"<<endl;
         evaluaMenuAsigYDesasig();
        }
}
//----------------------------------------------------------------------------
void controlUniversidad :: evaluaMenuAsigYDesasig(){
	int opciones = 0;
	do{
	opciones = menuProfAsigDes();
	switch(opciones){
	case 1:asignacionProfesores();
		break;

	case 2:quitaProfesCurso();
		break;
        case 3: evaluaMenuProf();
                getchar();
		exit(0);
		break;

	default:
		cout << "Error" << endl; 
                evaluaMenuProf();
	}
	} while(opciones != 4 && opciones != 0);
}
//---------------------Metodos implementados en el submenu de Profesores-----------
void controlUniversidad  ::incluye(){u->incluProf();}
void controlUniversidad  ::modifica(){u->modificarProf();}
void controlUniversidad  ::informacionProfesor(){u->datosProf();}
void controlUniversidad  ::muestraProfesEscuela(){u->verProf();}
void controlUniversidad ::asignacionProfesores(){u->asignaProfCurso();}
void controlUniversidad ::muestraProfesCurso(){u->verProfYCur();}
void controlUniversidad ::quitaProfesCurso(){u->deasignaProfCurso();}
void controlUniversidad ::director(){u->escuelaDirector();}
void controlUniversidad ::cargaAcademicaI(){u->cargaAcademicaU();}
//void controlUniversidad ::recuperaDat(){u->recuperarArcProf();}
//void controlUniversidad ::guardarDat(){u->guardarArcProf();}
//----------------------------ESTUDIANTES-----------------------------------------------------
 //--------------------------Submenu Estudiantes--------------------------------

int controlUniversidad::menuCursosEst() {
    int opciones = 0;
    char sNum[20];
    //system("color 0F");
    cout << "      ____________________________________________________________________       " << endl;
    cout << "     |                                                                    |      " << endl;
    cout << "     |                       Submenu de Estudiantes                        |      " << endl;
    cout << "     |                                                                    |      " << endl;
    cout << "     |                       -Sistema de Matricula-                       |      " << endl;
    cout << "     |                                                                    |      " << endl;
    cout << "     |____________________________________________________________________|      " << endl;
    cout << "     |      - Presione [1] para ingresar Estudiante                       |      " << endl;
    cout << "     |      - Presione [2] para modificar los datos de un Estudiante      |      " << endl;
    cout << "     |      - Presione [3] para mostrar los datos de un Estudiante        |      " << endl;
    cout << "     |      - Presione [4] para matricular                                |      " << endl;
    cout << "     |      - Presione [5] para asignar o desasignarestudiante a cursos   |      " << endl;
    cout << "     |      - Presione [6] mostrar cursos de un estudiante                |      " << endl;
    cout << "     |      - Presione [7] ver Costo De matricula                         |      " << endl;
    cout << "     |      - Presione [8] para volver al menu principal                  |      " << endl;
    cout << "     |____________________________________________________________________|      " << endl;
    cin >> sNum;
    opciones = atoi(sNum);
    if (opciones != 0) {
        return opciones;
    } else {
        cout << "!!!Error , se necesita digitar un numero" << endl;
        evaluaMenuProf();
    }
}

void controlUniversidad::evaluaMenuEst() {
    int opciones = 0;
    do {
        opciones = menuCursosEst();
        system("cmd /c pause");
        system("cmd /c cls");
        switch (opciones) {
            case 1:incluyeEst();
                break;

            case 2:modificaEst();
                break;

            case 3:informacionEst();
                break;

            case 4:matricularEst();
                break;
            case 5:evaluaMenuAsigYDesasigEst();
                break;
            case 6:mostrarTotalCurEst();
                break;
            case 7:montoTotalDeMatricula();
                break;
            case 8:evaluaMenu();
          
                getchar();
                exit(0);
                break;

            default:
                cout << "Error" << endl;
                evaluaMenuEst();
                system("cmd /c pause");
                system("cmd /c cls");
        }
    } while (opciones != 10 && opciones != 0);
}

int controlUniversidad::menuEstAsigYDes() {
    int opciones = 0;
    char sNum[20];
    //system("color 0F");
    cout << "      ____________________________________________________________________       " << endl;
    cout << "     |                                                                    |      " << endl;
    cout << "     |                       Submenu de Estudiantes                       |      " << endl;
    cout << "     |                                                                    |      " << endl;
    cout << "     |                       -Sistema de Matricula-                       |      " << endl;
    cout << "     |                                                                    |      " << endl;
    cout << "     |____________________________________________________________________|      " << endl;
    cout << "     |      - Presione [1] para asignar estudiante a cursos               |      " << endl;
    cout << "     |      - Presione [2] para desasignar estudiante a cursos            |      " << endl;
    cout << "     |      - Presione [3] para regresar al menu de estudiante            |      " << endl;
    cout << "     |____________________________________________________________________|      " << endl;
    cin >> sNum;
    opciones = atoi(sNum);
    if (opciones != 0) {
        return opciones;
    } else {
        cout << "!!!Error , se necesita digitar un numero" << endl;
        evaluaMenuAsigYDesasigEst();
    }
}

void controlUniversidad::evaluaMenuAsigYDesasigEst() {
    int opciones = 0;
    do {
        opciones = menuEstAsigYDes();
        system("cmd /c pause");
        system("cmd /c cls");
        switch (opciones) {
            case 1:asignarEst();
                break;

            case 2:quitarEstCursos();
                break;
            case 3: evaluaMenuEst();
                getchar();
                exit(0);
                break;
                system("cmd /c pause");
                system("cmd /c cls");
            default:
                cout << "Error" << endl;
                menuEstAsigYDes();
        }
    } while (opciones != 4 && opciones != 0);
}
//---------------------Metodos implementados en el submenu de Estudiantes-----------

void controlUniversidad::incluyeEst() { u->incluirEst();}
void controlUniversidad::modificaEst() { u->modificarEst();}
void controlUniversidad::informacionEst() {u->buscarEstudiante();}
void controlUniversidad::matricularEst() { u->matricular();}
void controlUniversidad::asignarEst() {  u->matricular();}
void controlUniversidad::muestraEstCurso() {  u->mostrarEstYCurso();}
void controlUniversidad::quitarEstCursos() { u->desasignarEst();}
void controlUniversidad::mostrarTotalCurEst() { u->mostrarCursosEstudiante();}
void controlUniversidad::montoTotalDeMatricula() { u->costoMatricula();}

controlUniversidad::~controlUniversidad() {
    delete u;
}

