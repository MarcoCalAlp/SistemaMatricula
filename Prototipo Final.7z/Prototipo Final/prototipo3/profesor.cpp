/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   profesor.cpp
 * Author: Johan y Marco
 * 
 * Created on 1 de mayo de 2017, 08:34 PM
 */

#include "profesor.h"
#include "curso.h"
#include "sstring.h"
//#include "listaCurso.h"

//-----------------------------------------------------------------------------
profesor::profesor(string nom, string ap1, string ap2 ,string id) : nombre(nom),apellido1(ap1),apellido2(ap2),cedula(id) {

}
//-----------------------------------------------------------------------------
profesor::profesor(profesor& c){
    this->nombre=c.nombre;
    this->apellido1=c.apellido1;
    this->apellido2=c.apellido2;
    this->cedula=c.cedula;
}
//-----------------------------------------------------------------------------
profesor::profesor()
{
    nombre=" ";
    apellido1=" ";
    apellido2=" ";
       cedula=" ";
    
}
//-----------------------------------------------------------------------------
string profesor::obtenerNombre() {
    return this->nombre;
}
//-----------------------------------------------------------------------------
string profesor::obtenerCedula() {
    return this->cedula;
}
//-----------------------------------------------------------------------------
string profesor::obtenerApellido1() {
    return this->apellido1;
}
//-----------------------------------------------------------------------------
string profesor::obtenerApellido2() {
    return this->apellido2;
}
//-----------------------------------------------------------------------------
void profesor::establecerNombre(string nom) {
    this->nombre = nom;
}
//-----------------------------------------------------------------------------
void profesor::establecerApellido1(string ap1) {
    this->apellido1 = ap1;
}
//-----------------------------------------------------------------------------
void profesor::establecerApellido2(string ap2) {
    this->apellido2 = ap2;
}
//-----------------------------------------------------------------------------
void profesor :: establecerCedula(string ced){
    this->cedula=ced;    
}
//-----------------------------------------------------------------------------

string profesor::imprime() {
    stringstream s;
    s << "Nombre: " << nombre << endl;
    s << "Apellido1: " << apellido1 << endl;
    s << "Apellido2: " << apellido2 << endl;
    s << "Cedula: " << cedula << endl;
    s << endl << endl;
    return s.str();
}
//-----------------------------------------------------------------------------
  
profesor::~profesor() {
}
profesor::profesor(ifstream& entrada){
      deserialize(entrada, this);
}
bool profesor::guardar(ofstream& salida) {
  
 return serialize(salida, (profesor*)this);
}
void profesor::deserialize(ifstream& entrada, profesor* p){
    p->nombre = sstring::deserialize(entrada);
    p->apellido1= sstring::deserialize(entrada);
    p->apellido2= sstring::deserialize(entrada);
    p->cedula = sstring::deserialize(entrada);
	if(!entrada.good())
		throw -1;
}
//Este método serializa(guarda) la informacion del cliente
//en el archivo
bool profesor::serialize(ofstream &salida,profesor* p) {
    
    sstring::serialize(salida, p->nombre);
    sstring::serialize(salida,p->apellido1);
    sstring::serialize(salida,p->apellido2);
    sstring::serialize(salida, p->cedula);
    
    return salida.good();
}