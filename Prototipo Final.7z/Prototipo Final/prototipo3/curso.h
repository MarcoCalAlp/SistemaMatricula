/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   curso.h
 * Author: marcovinicio
 *
 * Created on 22 de marzo de 2017, 10:00 PM
 */

#ifndef CURSO_H
#define CURSO_H
#include "profesor.h"
#include "estudiante.h"
#include "listaEstudiante.h"
#include "listaProfesor.h"
//#include "iteradorLista.h"
//#include<iostream>
//#include<sstream>
//
//
//
//using namespace std;

class curso  {
public:
    //-----------------CURSOS--------------------
    curso();
    virtual void estableceSigla(string);
    virtual string obtieneSigla();
    virtual void estableceNombreC(string);
    virtual string obtieneNombreC();
    void establecerCreditos(int);
    int obtenerCreditos();
    curso(string,string,int);
    virtual string imprime();
    virtual void imprimeTodo();
    
    //---------------PROFES-------------------------
    virtual void asignaProf(lista<profesor>* );
    virtual void desasignaProf();
    virtual void muestraProfCur();
    virtual void retornaCurso(lista<profesor>*);
    virtual void recuperarPr(string,ifstream&);
    virtual void guardarPr(lista<profesor>*,string,ofstream&);
     //-----------Estudiantes------------------------
    virtual void matricularEst(lista<estudiante> *);
    virtual  void desasignaEst();
    virtual void mostrarEst();
    virtual void imprimirCursoEst(estudiante*);
    virtual int creditosEst(estudiante*);
    //-----------Ley de 3--------------------------
    
    virtual curso& operator=(const curso&);
    curso(const curso&);
    virtual ~curso();
    
    
    // metodos relacionados con cursos
    curso(ifstream&);
    virtual bool guardar(ofstream&);
    static void deserialize(ifstream&, curso*);
    static bool serialize(ofstream&, curso*);
    
private:
    string sigla;
    string nomCurso;
    int creditos;
    listaProfesor* lp;
    iterador<profesor>* itp;
    listaEstudiante* les;
    iterador<estudiante>* ites;
    //listaEstudiante* s;
    //estudiante *e;

    

};

#endif /* CURSO_H */

