/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   escuela.cpp
 * Author: marcovinicio
 * 
 * Created on 9 de marzo de 2017, 07:29 PM
 */

#include "escuela.h"


//------------------------ESCUELAS--------------------------------------------
escuela::escuela() {
    nombre="";
    lc=new listaCurso();
    lp2=new listaProfesor();
}
//---------------------------------------------------------------------------
escuela::escuela(string nombre) {   
    this->nombre=nombre;
   lc=new listaCurso();
    lp2=new listaProfesor();
}
//----------------------------------------------------------------------------
void escuela:: estNombre(string Tnombre){
    this->nombre=Tnombre;
}
//----------------------------------------------------------------------------
string escuela:: obtNombre(){
   return this->nombre; 
}
//----------------------------------------------------------------------------
string  escuela:: imprime(){
        stringstream s;
	s<<"Nombre de la escuela:"<<this->nombre<<endl;
        s<<endl;
        return s.str();
}
//------------------------CURSOS----------------------------------------------

void escuela:: imprimeCurYesc(){
    cout<<"//////////////////////////////////////////////"<<endl;
    cout<<"------------ESCUELA:"<<this->nombre<<endl;
    cout<<"->Cursos de la escuela actualmente:"<<endl;
    cout<<endl;
    curso* aux = NULL;
    itc = lc->obtenerIterador();
    while(itc->masElementos())
    {
        aux = itc->proximoElemento();
        aux->imprimeTodo();
    }
    
  }
//----------------------------------------------------------------------------

void escuela::ingresaCursos() {
    string a, b;
    int n;
    cout << "->Digite la sigla del curso" << endl;
    cin>>a;
    cout << "->Digite el nombre del curso" << endl;
    cin>>b;
    cout << "Los creditos solo puden ser 3-4 por curso!" << endl;

    cout << "->Digite los creditos del curso" << endl;
    cin>>n;
    if (n != 3 || n != 4) {
        cout << "Los creditos solo puden ser 3-4 por curso!" << endl;

        cout << "->Digite los creditos del curso" << endl;
        cin>>n;
    }
    c = new curso();
    c->estableceSigla(a);
    c->estableceNombreC(b);
    c->establecerCreditos(n);
    lc->agregarFinal(c);
    
 }
 //---------------------------------------------------------------------------
 void escuela::modificaCursoSigla(){
     string a,b;
     bool x=false;
     cout<<"->Digite la sigla del curso a modificar"<<endl;
     cin>>a;    
     curso* aux = NULL;
     itc = lc->obtenerIterador();
    while(itc->masElementos())
    {
        aux = itc->proximoElemento();
        if(aux->obtieneSigla()==a){
        x=true;
        cout<<"->Digite la nueva sigla del curso "<<endl;
        cin>>b;
        aux->estableceSigla(b);
        }
        
    }
     if(x==false){cout<<"Error!!!, no se ha podido encontrar la sigla"<<endl;}
 }
 //---------------------------------------------------------------------------
 void escuela::modificaCursoNombre(){
     string a,b;
     bool x=false;
     cout<<"->Digite el nombre del curso a modificar"<<endl;
     cin>>a; 
     curso* aux = NULL;
     itc = lc->obtenerIterador();
    while(itc->masElementos())
    {
        aux = itc->proximoElemento();
        if(aux->obtieneNombreC()==a){
        x=true;
        cout<<"->Digite el nuevo nombre del curso "<<endl;
        cin>>b;
        aux->estableceNombreC(b);
        }
        
    }
      if(x==false){cout<<"Error!!!, no se ha podido encontrar la sigla"<<endl;}
 }
 //---------------------------------------------------------------------------
 void escuela::muestraCursos(){
    curso* aux = NULL;
    itc = lc->obtenerIterador();
    while(itc->masElementos())
    {
        aux = itc->proximoElemento();
        cout<<aux->imprime();
    }
     
 }
 //---------------------------------------------------------------------------
 void escuela::eliminaCursos(){
     string a,b;
     bool x=false;
     cout<<"->Digite las siglas de curso a borrar"<<endl;
     cin>>a;
     cout<<"->Digite el nombre del curso a borrar"<<endl;
     cin>>b;
    curso* aux = NULL;
    itc = lc->obtenerIterador();
    while(itc->masElementos())
    {
        
        aux = itc->proximoElemento();
        if(aux->obtieneSigla()==a&&aux->obtieneNombreC()==b){
            x=true;
            lc->eliminar(aux);
        }
    }
    if(x==false){cout<<"Error!!!, la informacion del curso digitado no existe!"<<endl;}
     
 }
 //---------------------------------------------------------------------------
 
  void escuela::informacionCurso(){
     string a;
     bool x=false;
     cout<<"->Digite el nombre del curso al que le desea verificar los datos"<<endl;
     cin>>a;
    curso* aux = NULL;
    itc = lc->obtenerIterador();
    while(itc->masElementos())
    {
        aux = itc->proximoElemento();
        if(aux->obtieneNombreC()==a){
            x=true;
            cout<<aux->imprime();
        }
    }
     if(x==false){cout<<"Error!!!, no se ha podido encontrar el curso"<<endl;}
 }
  //------------------------------------------------------------------------
  curso* escuela::retornaCur()
  {
      /*string a;
      cout<<"Digite el nombre del curso "<<endl;
      cin>>a;
      curso * c1=new curso();
      c1->estableceNombreC(a);
      if((curso*)d->buscar(c1)!= NULL)
      {
          return c1=(curso*)d->buscar(c1);
      }
      else 
      {
          cout<<"El curso digitado no se encuentra inscripto en la escuela! "<<endl;
          retornaCur();
      }*/
      string a;
     bool x=false;
     cout<<"->Digite el nombre del curso "<<endl;
     cin>>a;
    curso* aux = NULL;
    itc = lc->obtenerIterador();
    while(itc->masElementos())
    {
        aux = itc->proximoElemento();
        if(aux->obtieneNombreC()==a){
            x=true;
            return aux;
        }
    }
     if(x==false){cout<<"Error!!!, no se ha podido encontrar el curso"<<endl; retornaCur();}
  }
  
 
 //--------------------------PROFESORES--------------------------------------

profesor * escuela:: ingresaProf(){
     string a,b,c,e;
     cout<<"->Digite el numero de cedula del profesor"<<endl;
     cin>>e;
     cout<<"->Digite el nombre del profesor"<<endl;
     cin>>a;
     cout<<"->Digite el primer apellido del profesor"<<endl;
     cin>>b;
     cout<<"->Digite el segundo apellido del profesor"<<endl;
     cin>>c;
     t=new profesor(a,b,c,e);
     lp2->agregarFinal(t); 
     return t;
 }
 //---------------------------------------------------------------------------
 void escuela::modificaNombreProf(){
     string a,b;
     bool x=false;
     cout<<"->Digite el nombre del profesor a modificar"<<endl;
     cin>>a;
     profesor* aux = NULL;
     itp2 = lp2->obtenerIterador();
    while(itp2->masElementos())
    {
        aux = itp2->proximoElemento();
        if(aux->obtenerNombre()==a){
        x=true;
        cout<<"->Digite el nuevo nombre del profesor "<<endl;
        cin>>b;
        aux->establecerNombre(b);
        }
        
    }
      if(x==false){cout<<"Error!!!, no se ha podido encontrar el profesor "<<endl;}
 }
 //--------------------------------------------------------------------------
 void escuela::modificaApellidoIProf(){
     string a,b;
     bool x=false;
     cout<<"->Digite el primer apellido del profesor a modificar"<<endl;
     cin>>a;  
     profesor* aux = NULL;
     itp2 = lp2->obtenerIterador();
    while(itp2->masElementos())
    {
        aux = itp2->proximoElemento();
        if(aux->obtenerApellido1()==a){
        x=true;
        cout<<"->Digite el nuevo apellido I del profesor "<<endl;
        cin>>b;
        aux->establecerApellido1(b);
        }
        
    }
     if(x==false){cout<<"Error!!!, no existe el apellido buscado!"<<endl;}
 
 }
 //-------------------------------------------------------------------------
 void escuela::modificaApellidoIIProf(){
     string a,b;
     bool x=false;
     cout<<"->Digite el segundo apellido del profesor a modificar"<<endl;
     cin>>a;  
     profesor* aux = NULL;
     itp2 = lp2->obtenerIterador();
    while(itp2->masElementos())
    {
        aux = itp2->proximoElemento();
        if(aux->obtenerApellido2()==a){
         x=true;
        cout<<"->Digite el nuevo apellido II del profesor "<<endl;
        cin>>b;
        aux->establecerApellido2(b);
        }
        
    }
      if(x==false){cout<<"Error!!!, no se ha podido encontrar el apellido buscado"<<endl;}
 }
 //---------------------------------------------------------------------------
 void escuela::muestraProfes(){
    profesor* aux = NULL;
    itp2 = lp2->obtenerIterador();
    while(itp2->masElementos())
    {
        aux = itp2->proximoElemento();
        cout<<aux->imprime();
    }
     
 }
 //---------------------------------------------------------------------------
 
  void escuela::informacionProf(){
     string a;
     bool x=false;
     cout<<"->Digite el numero de cedula del Profesor al que le desea verificar los datos"<<endl;
     cin>>a;
    profesor* aux = NULL;
    itp2 = lp2->obtenerIterador();
    while(itp2->masElementos())
    {
        aux = itp2->proximoElemento();
        if(aux->obtenerCedula()==a){
            x=true;
            cout<<aux->imprime();
        }
    }
     if(x==false){cout<<"Error!!!, no se ha podido encontrar el profesor"<<endl;}
 }
  //--------------------------------------------------------------------------
  
void escuela::asigna(){
    
     string a;
     bool x=false;
     cout<<"->Digite el nombre del curso al que se le desea incluir el profesor"<<endl;
     cin>>a;
    curso* aux = NULL;
    itc = lc->obtenerIterador();
    while(itc->masElementos())
    {
        aux = itc->proximoElemento();
        if(aux->obtieneNombreC()==a){
            x=true;
            curso*cur=aux;
            cur->asignaProf(lp2);   
            cout<<"Curso asignado correctamente!!!"<<endl;
        }
    }
     if(x==false){cout<<"Error!!!, no se ha podido encontrar el curso"<<endl;}
}
//----------------------------------------------------------------------------
void escuela::muestraProfPorCur(){
    
     string a;
     bool x=false;
     cout<<"->Digite el nombre del curso al que se le desea ver los profesores"<<endl;
     cin>>a;
    curso* aux = NULL;
    itc = lc->obtenerIterador();
    while(itc->masElementos())
    {
        aux = itc->proximoElemento();
        if(aux->obtieneNombreC()==a){
            x=true;
            curso*cur=aux;
            cur->muestraProfCur();   
        }
    }
     if(x==false){cout<<"Error!!!, no se ha podido encontrar el curso"<<endl;}
}
//----------------------------------------------------------------------------
void escuela::desasigna(){
    
     string a;
     bool x=false;
     cout<<"->Digite el nombre del curso al  que se le desea desasignar profesores"<<endl;
     cin>>a;
     curso* aux = NULL;
     itc = lc->obtenerIterador();
     while(itc->masElementos())
    {
        aux = itc->proximoElemento();
        if(aux->obtieneNombreC()==a){
            x=true;
            curso*cur=aux;
            cur->desasignaProf();   
        }
    }
    if(x==false){cout<<"Error!!!, no se ha podido encontrar el curso"<<endl;}
}
//----------------------------------------------------------------------------
void escuela::asignaDirector(){
    
    string a;
    bool x=false;
     cout<<"->Digite el numero de cedula del Profesor  al que quiere asignar como director"<<endl;
     cin>>a;
    profesor* aux = NULL;
    itp2 = lp2->obtenerIterador();
    while(itp2->masElementos())
    {
        aux = itp2->proximoElemento();
        if(aux->obtenerCedula()==a){
         x=true;
         cout<<"El profesor:"<<aux->obtenerNombre()<<" "<<aux->obtenerApellido1()<<" "<<aux->obtenerApellido2()<<" "<<endl;
         cout<<"Ha sido asignado como director"<<endl;
        }
    }
     if(x==false){cout<<"Error!!!, no se ha podido encontrar el profesor"<<endl;}
}
void escuela:: ambosPyC(){
    
     curso* aux = NULL;
     itc = lc->obtenerIterador();
     while(itc->masElementos())
    {
        aux = itc->proximoElemento();
        aux->imprimeTodo();
    }
    
}
//----------------------------------------------------------------------------
void escuela::cargaAcademica(){
     curso* aux = NULL;
     itc = lc->obtenerIterador();
     while(itc->masElementos())
    {
        aux = itc->proximoElemento();
        aux->retornaCurso(lp2);
    }
}

 void escuela:: recuperaProfA(string m,ifstream& entrada){
     curso* aux = NULL;
     itc = lc->obtenerIterador();
     while(itc->masElementos())
    {
        aux = itc->proximoElemento();
        aux->recuperarPr(m,entrada);
    }
  }
 //----------------------------------------------------------
 void escuela::  guardaProfA(string m,ofstream& salida){
    curso* aux = NULL;
    itc = lc->obtenerIterador();
    while(itc->masElementos())
    {
        aux = itc->proximoElemento();
        aux->guardarPr(lp2,m,salida);     
    }
  }
//-------------------ESTUDIANTES-----------------------------------------
void escuela::matricularEstu(lista<estudiante> *s)
{
      retornaCur()->matricularEst(s);// matricula a un estudiante en un curso
}
//----------------------------------------------------------------------------
void escuela::imprimirCursoPorEstudiante(estudiante * est)
  {
     //d->imprimeCursoPorEst(est);
     curso* aux = NULL;
     itc = lc->obtenerIterador();
     while(itc->masElementos())
    {
        aux = itc->proximoElemento();
        aux->imprimirCursoEst(est);
    }
  }
//--------------------------------------------------------------------------------
int escuela::totalCreditosCurso(estudiante* est)
{
    //return d->numeroCreditos(est);
    int total;
    curso* aux = NULL;
     itc = lc->obtenerIterador();
     while(itc->masElementos())
    {
        aux = itc->proximoElemento();
        total=total+aux->creditosEst(est);
        
    }
     return total;
}
//----------------Ley de 3---------------------------
escuela& escuela::operator=(const escuela &ca) {
    if (this != &ca) {
        lc=ca.lc;
        itc=ca.itc;
        lp2=ca.lp2;
        itp2=ca.itp2;
        nombre=ca.nombre;
    }
    return *this;
}
//-------------------------------------------------------------------------
escuela::escuela(const escuela &ca) {
        lc=ca.lc;
        itc=ca.itc;
        lp2=ca.lp2;
        itp2=ca.itp2;
        nombre=ca.nombre;
}
//-------------------------------------------------------------------------
escuela::~escuela() {
    
    
}
//metodos relacionados con archivos 

escuela::escuela(ifstream& entrada){
      deserialize(entrada, this);
}
void escuela::deserialize(ifstream& entrada, escuela* es) {
   es->nombre = sstring::deserialize(entrada);
    es->lp2=new listaProfesor();
      es->lc=new listaCurso();
    if (!entrada.good())
        throw -1;
}

bool escuela::serialize(ofstream& salida, escuela* es) {
    sstring::serialize(salida, es->nombre);
   es->lp2->guardar(salida);
    es->lc->guardar(salida);
     //  sstring::serialize(salida, cur->les);
    return salida.good();
}

bool escuela::guardar(ofstream& salida){
    serialize(salida, (escuela*)this);
}