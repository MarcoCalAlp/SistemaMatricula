
#ifndef ITERADOR_H
#define ITERADOR_H

template <class T>
class iterador {
public:
    iterador();

    virtual bool masElementos() const = 0;
    virtual T* proximoElemento() = 0;
};

template <class T>
iterador<T>::iterador() {
    
}

#endif /* ITERADOR_H */

