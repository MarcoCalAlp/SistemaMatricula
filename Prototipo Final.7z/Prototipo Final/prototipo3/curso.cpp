/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   curso.cpp
 * Author: marcovinicio y johan
 * 
 * Created on 22 de marzo de 2017, 10:00 PM
 */

#include "curso.h"
#include "profesor.h"
#include "listaProfesor.h"
//-----------------------------------------------------------------------------
curso::curso() {
    sigla="";
    nomCurso="";
    creditos=0;
     lp= new listaProfesor();
     les=new listaEstudiante();
}
//-----------------------------------------------------------------------------
void curso::estableceSigla(string pSigla){
    this->sigla=pSigla;
}
//-----------------------------------------------------------------------------
string curso::obtieneSigla(){
    return this->sigla;
}
//-----------------------------------------------------------------------------
void curso:: estableceNombreC(string pNombre){
    this->nomCurso=pNombre;
}
//-----------------------------------------------------------------------------
string curso::obtieneNombreC(){
    return this->nomCurso;
}
//-----------------------------------------------------------------------------
int curso::obtenerCreditos()
{
    return creditos;
}
//-----------------------------------------------------------------------------
void curso::establecerCreditos(int cred)
{
    creditos=cred;
}
//-----------------------------------------------------------------------------
curso::curso(string pSigla,string nombCurso,int credit){
    this->sigla=pSigla;
    this->nomCurso=nombCurso;
    creditos=credit;
    lp= new listaProfesor();
         les=new listaEstudiante();
}
//-----------------------------------------------------------------------------
string curso:: imprime(){
    stringstream n;
    n<<"Nombre del curso:"<<this->nomCurso<<endl;
    n<<"Sigla del curso:"<<this->sigla<<endl;
    n<<"Creditos "<<creditos<<endl;
    n<<"----->"<<endl;
    n<<"----------------------------------------------------------------"<<endl;
    
    return n.str();
}
//-----------------------------------------------------------------------------
void curso::imprimeTodo(){
    cout<<"Nombre del curso:"<<this->nomCurso<<endl;
    cout<<"Sigla del curso:"<<this->sigla<<endl;
    cout<<"Creditos "<<creditos<<endl;
    cout<<"------>"<<endl;
    muestraProfCur();
    cout<<endl;
    cout<<"----------------------------------------------------------------"<<endl;
  }
//---------------------------PROFESORES--------------------------------------------------

void curso::asignaProf(lista<profesor>* m){
     string a;
     bool x=false;
     cout<<"-->Digite la cedula del profesor al que se le va asignar el curso"<<endl;
     cin>>a;
    profesor* aux = NULL;
    iterador<profesor>*p;
    p= m->obtenerIterador();
    //string archivo = "profes.txt";
    //ofstream salida(archivo.c_str()); 
    while(p->masElementos())
    {
        aux = p->proximoElemento();
        if(aux->obtenerCedula()==a){
        x=true;
        lp->agregarFinal(aux); 
        //aux->guardar(salida);
        }
    }
     //salida.close();
     if(x==false){cout<<"Error!!!, no se ha podido encontrar el profesor"<<endl;}
    
}
//-----------------------------------------------------------------------------
void curso::muestraProfCur(){
     cout<<"------------- CURSO:"<<this->obtieneNombreC()<<endl;
     cout<<"*****PROFESORES del curso actualmente:"<<endl<<endl;
     cout<<endl;
    profesor* aux = NULL;
    itp = lp->obtenerIterador();
    while(itp->masElementos())
    {
        aux = itp->proximoElemento();
        cout<<aux->imprime();
    }
  }


//-----------------------------------------------------------------------------
void curso::desasignaProf(){
     string a;
     bool x=false;
     cout<<"->Digite la cedula del profesor a desasignar del curso "<<endl;
     cin>>a;
    profesor* aux = NULL;
    itp = lp->obtenerIterador();
   // string archivo = "profes.txt";
    while(itp->masElementos())
    {
        aux = itp->proximoElemento();
        if(aux->obtenerCedula()==a){
            x=true;
            lp->eliminar(aux);
            //string archivo = "profes.txt";
            //ofstream salida(archivo.c_str()); 
            //aux->guardar(salida);
            //cout<<"Guardando . . ."<<endl;
        }
    }
    if(x==false){cout<<"Error!!!, no se ha podido encontrar el profesor"<<endl;}
    
}

//----------------------------------------------------------------
void curso::retornaCurso(lista<profesor>* m){
     string b;
     bool x=false;
     cout<<"-->Digite la cedula del profesor al que le desea ver los cursos"<<endl;
     cin>>b;
    profesor* aux = NULL;
    iterador<profesor>*p;
    p= m->obtenerIterador();
    while(p->masElementos())
    {
        aux = p->proximoElemento();
        if(aux->obtenerCedula()==b){
            x=true;
         cout<< this->imprime();  
        }
    }
    if(x==false){cout<<"Error!!!, no se ha podido encontrar el profesor"<<endl;}
     
}
//----------------------------------------------------------------
void curso::guardarPr(lista<profesor>*m,string t,ofstream& salida){
        profesor* aux = NULL;
        iterador<profesor>*p;
        p= m->obtenerIterador();
        string archivo = t;
        //ofstream salida(archivo.c_str()); 
        while(p->masElementos())
         {
            aux = p->proximoElemento();
            aux->guardar(salida);
           
            
        }
     // salida.close();
}
//----------------------------------------------------------------
 void curso::recuperarPr(string t,ifstream& entrada){
     
    
    string archivo = t;
    //ifstream entrada(archivo.c_str());
    profesor* pf = new profesor(entrada);
    entrada.close();
    cout<<"Datos recuperados:"<<endl;
    cout<<pf->imprime();
 }
//-----------------------Estudiantes-----------------------------------------
void curso::matricularEst(lista<estudiante>* m)
{
     /*string b;
 
     cout<<"-->Digite la cedula del estudiante al que se le va asignar el curso"<<endl;
     cin>>b;
    
     e=new estudiante();
     e->establecerCedula(b);
     
    cout<< m->buscar(e)->imprime();
     if(m->buscar(e)!=NULL)
    {
        e= m->buscar(e);
        s->insertar(e);    
        cout<<"estudiante asignado exitosamente!!"<<endl; 
    }
    else
        cout<<"Error!!! Se necesita que el estudiante este inscrito en la universidad"<<endl;*/
     string a;
     bool x=false;
     cout<<"-->Digite la cedula del estudiante al que se le va asignar el curso"<<endl;
     cin>>a;
    estudiante* aux = NULL;
    iterador<estudiante>*e;
    e= m->obtenerIterador();
    while(e->masElementos())
    {
        aux = e->proximoElemento();
        if(aux->obtenerCedula()==a){
        x=true;
        les->agregarFinal(aux);  
        cout<<"estudiante asignado exitosamente!!"<<endl;
        }
    }
     if(x==false){cout<<"Error!!!, no se ha podido encontrar el estudiante"<<endl;}
}
void curso::desasignaEst(){
    /* string a;
     cout<<"->Digite la cedula del estudiante a desasignar del curso "<<endl;
     cin>>a;
     e=new estudiante();
     e->establecerCedula(a);
     s->borrar(e);*/
     string a;
     bool x=false;
     cout<<"->Digite la cedula del estudiante a desasignar del curso "<<endl;
     cin>>a;
    estudiante* aux = NULL;
    ites = les->obtenerIterador();
    while(ites->masElementos())
    {
        aux = ites->proximoElemento();
        if(aux->obtenerCedula()==a){
            x=true;
            les->eliminar(aux);
        }
    }
    if(x==false){cout<<"Error!!!, no se ha podido encontrar el estudiante"<<endl;}
}
void curso::mostrarEst()
{
    cout<<".........Informacion de Estudiantes........ "<<endl;
    estudiante* aux = NULL;
    ites = les->obtenerIterador();
    while(ites->masElementos())
    {
        aux = ites->proximoElemento();
        cout<<aux->imprime();
    }
    cout<<endl;
    //s->mostrar();
}
void curso::imprimirCursoEst(estudiante * est2)
{

   /* if(s->buscar(est2)->obtenerCedula()==est2->obtenerCedula()){
        cout<<nomCurso<<endl;
        cout<<sigla<<endl;
        cout<<endl;
    }*/
    estudiante* aux = NULL;
    ites = les->obtenerIterador();
    while(ites->masElementos())
    {
        aux = ites->proximoElemento();
        if(aux->obtenerCedula()==est2->obtenerCedula()){
        cout<<nomCurso<<endl;
        cout<<sigla<<endl;
        cout<<endl; 
        
        }
    }
    
    
}
int curso::creditosEst(estudiante*est2)
{
      /*if(s->buscar(est2)->obtenerCedula()==est2->obtenerCedula()){
          return creditos;
    }*/
    estudiante* aux = NULL;
    ites = les->obtenerIterador();
    while(ites->masElementos())
    {
        aux = ites->proximoElemento();
        if(aux->obtenerCedula()==est2->obtenerCedula()){
         return creditos; 
        }
    }
}
//--------------------LEY DE 3------------------------------
curso::curso(const curso &ca) {
   
    lp=ca.lp;
    itp=ca.itp;
    sigla= ca.sigla;
    nomCurso=ca.nomCurso;
}
//----------------------------------------------------
curso& curso::operator=(const curso &ca) {
    if (this != &ca) {
    lp=ca.lp;
    itp=ca.itp;
    sigla= ca.sigla;
    nomCurso=ca.nomCurso;
    }
    return *this;
}

//------------------------------------------------------
curso::~curso() {
    
}

//metodos relacionados con archivos 

curso::curso(ifstream& entrada){
      deserialize(entrada, this);
}
void curso::deserialize(ifstream& entrada, curso* cur) {
    cur->nomCurso = sstring::deserialize(entrada);
    cur->sigla = sstring::deserialize(entrada);
    entrada.read((char*) &cur->creditos, sizeof (cur->creditos));
    cur->lp=new listaProfesor();
      cur->les=new listaEstudiante();
    if (!entrada.good())
        throw -1;
}

bool curso::serialize(ofstream& salida, curso* cur) {
    sstring::serialize(salida, cur->nomCurso);
    sstring::serialize(salida, cur->sigla);
    salida.write((char*) &cur->creditos, sizeof (cur->creditos));
    cur->lp->guardar(salida);
    cur->les->guardar(salida);
     //  sstring::serialize(salida, cur->les);
    return salida.good();
}

bool curso::guardar(ofstream& salida){
    serialize(salida, (curso*)this);
}