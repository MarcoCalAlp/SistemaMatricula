/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   universidad.cpp
 * Author: marcovinicio y johan
 * 
 * Created on 9 de marzo de 2017, 07:28 PM
 */

#include "universidad.h"

//------------------------------UNIVERSIDAD------------------------------------

universidad::universidad() {

    this->nombre = "";
    this->direccion = "";
    this->telefono = 0;
    le = new listaEscuela();
    ls = new listaEstudiante();
}
//-----------------------------------------------------------------------------

universidad::universidad(string nombre, string direccion, int telefono) : nombre(nombre), direccion(direccion), telefono(telefono) {
    le = new listaEscuela();
    ls = new listaEstudiante();
}
//-----------------------------------------------------------------------------

void universidad::estNombre(string Pnombre) {
    this->nombre = Pnombre;
}
//-----------------------------------------------------------------------------

string universidad::imprimeDatos() {
    stringstream s;
    s << "Nombre de la Universidad:" << this->nombre << endl;
    s << "Direccion de la Universidad:" << this->direccion << endl;
    s << "Numero de la Universidad:" << this->telefono << endl;
    s <<le->toString();
    s <<ls->toString();
    s << endl;
    return s.str();
}
//----------------------------------------------------------------------------
string universidad:: imprimeRecuperar(){
    stringstream s;
    s << imprimeDatos();
    //s <<endl;
    s <<le->toString();
    //s <<endl;
    s <<ls->toString();
    return s.str();
    
}
//----------------------------------------------------------------------------

void universidad::estDireccion(string Pdireccion) {
    this->direccion = Pdireccion;
}
//-----------------------------------------------------------------------------

void universidad::estTelefono(int Ptelefono) {
    this->telefono = Ptelefono;
}
//-----------------------------------------------------------------------------

string universidad::obtNombre() {
    return this->nombre;
}
//-----------------------------------------------------------------------------

string universidad::obtDireccion() {
    return this->direccion;
}
//-----------------------------------------------------------------------------

int universidad::obtTelefono() {
    return this->telefono;
}
//----------------------------ESCUELAS-----------------------------------------

void universidad::registraEscuelas() {
    string a;
    cout << "Digite el nombre de la escuela" << endl;
    cin>>a;
    e1 = new escuela();
    e1->estNombre(a);
    le->agregarFinal(e1);
}
//-----------------------------------------------------------------------------

void universidad::muestraEscuelas() {
    escuela* aux = NULL;
    ite = le->obtenerIterador();
    while (ite->masElementos()) {
        aux = ite->proximoElemento();
        cout << aux->imprime();
    }
}

//-----------------------------CURSOS----------------------------------------

void universidad::incluCursosU() {
    string a;
    bool x = false;
    cout << "-->Digite el nombre de la escuela a la que se le desea incluir los cursos<--" << endl;
    cin>>a;
    escuela* aux = NULL;
    ite = le->obtenerIterador();
    while (ite->masElementos()) {
        aux = ite->proximoElemento();
        if (aux->obtNombre() == a) {
            aux->ingresaCursos();
            x = true;
        }
    }

    if (x == false) {
        cout << "Error no se pudo encontrar la escuela" << endl;
    }

}
//---------------------------------------------------------------------------

void universidad::verCursos() {

    string a;
    bool x = false;
    cout << "-->Digite el nombre de la escuela a la que se le desea ver los cursos<--" << endl;
    cin>>a;
    escuela* aux = NULL;
    ite = le->obtenerIterador();
    while (ite->masElementos()) {
        aux = ite->proximoElemento();
        if (aux->obtNombre() == a) {
            x = true;
            aux->imprimeCurYesc();
        }
    }
    if (x == false) {
        cout << "Error no se pudo encontrar la escuela" << endl;
    }

}
//----------------------------------------------------------------------------

void universidad::borrarCursos() {
    string a;
    bool x = false;
    cout << "-->Digite el nombre de la escuela a la que se le desea eliminar los cursos<--" << endl;
    cin>>a;
    escuela* aux = NULL;
    ite = le->obtenerIterador();
    while (ite->masElementos()) {
        aux = ite->proximoElemento();
        if (aux->obtNombre() == a) {
            x = true;
            aux->eliminaCursos();
        }
    }
    if (x == false) {
        cout << "Error no se pudo encontrar la escuela" << endl;
    }
    /*string a;
    cout<<"-->Digite el nombre de la escuela a la que le desea eliminar los cursos<--"<<endl;
    cin>>a;
    escuela *e2=new escuela(a);
    if(k->buscar(e2)!=NULL){
    escuela*aux=k->buscar(e2);
    aux->eliminaCursos();    
    }
    else
        cout<<"¡error!, el nombre de la escuela no ha sido encontrada"<<endl;*/
}
//----------------------------------------------------------------------------

void universidad::modificarCurso() {
    string a;
    bool x = false;
    cout << "--->Digite el nombre de la escuela a la que le desea modificar algun curso<---" << endl;
    cin>>a;
    //-----------------------------------------------------------------
    escuela* aux = NULL;
    ite = le->obtenerIterador();
    while (ite->masElementos()) {
        aux = ite->proximoElemento();
        if (aux->obtNombre() == a) {
            x = true;
            int aa;
            cout << "**************************************************************" << endl;
            cout << "*  Digite 1 si desea modificar solo el nombre del curso      *" << endl;
            cout << "*  Digite 2 si desea modificar solo la sigla del curso       *" << endl;
            cout << "* Digite 3 si desea modificar el nombre y la sigla del curso *" << endl;
            cout << "**************************************************************" << endl;
            cin>>aa;
            switch (aa) {

                case 1:aux->modificaCursoNombre();
                    break;

                case 2:aux->modificaCursoSigla();
                    break;
                case 3:aux->modificaCursoNombre();
                    aux->modificaCursoSigla();
                    break;
                default:
                    cout << "Error" << endl;
            }
        }
    }
    if (x == false) {
        cout << "Error no se pudo encontrar la escuela" << endl;
    }

}
//-----------------------------------------------------------------------------

void universidad::verCursosTotal() {

    escuela* aux = NULL;
    ite = le->obtenerIterador();
    cout << "INFORMACION DE ESCUELAS :" << endl;
    while (ite->masElementos()) {
        aux = ite->proximoElemento();
        aux->imprimeCurYesc();
    }
}
//-----------------------------------------------------------------------------

void universidad::datosCurso() {
    string a;
    bool x = false;
    cout << "-->Digite el nombre de la escuela a la que se le desea eliminar los cursos<--" << endl;
    cin>>a;
    escuela* aux = NULL;
    ite = le->obtenerIterador();
    while (ite->masElementos()) {
        aux = ite->proximoElemento();
        if (aux->obtNombre() == a) {
            x = true;
            aux->informacionCurso();
        }
    }
    if (x == false) {
        cout << "Error no se pudo encontrar la escuela" << endl;
    }

}
//------------------------PROFESORES-------------------------------------------

void universidad::incluProf() {

    string a;
    bool x = false;
    cout << "-->Digite el nombre de la escuela a la que se le desea incluir los cursos<--" << endl;
    cin>>a;
    escuela* aux = NULL;
    ite = le->obtenerIterador();
    while (ite->masElementos()) {
        aux = ite->proximoElemento();
        if (aux->obtNombre() == a) {
            x = true;
            aux->ingresaProf();
        }
    }
    if (x == false) {
        cout << "Error no se pudo encontrar la escuela" << endl;
    }
}
//-----------------------------------------------------------------------------

void universidad::modificarProf() {
    string a;
    bool x = false;
    cout << "--->Digite el nombre de la escuela donde esta inscrito el profesor<---" << endl;
    cin>>a;
    escuela* aux = NULL;
    ite = le->obtenerIterador();
    while (ite->masElementos()) {
        aux = ite->proximoElemento();
        if (aux->obtNombre() == a) {
            x = true;
            int aa;
            cout << "--------------------------------------------------------------------" << endl;
            cout << "-   Digite 1 si desea modificar  el nombre del profesor            -" << endl;
            cout << "-   Digite 2 si desea modificar  el primer apellido del profesor   -" << endl;
            cout << "-   Digite 3 si desea modificar el  segundo apellido del profesor  -" << endl;
            cout << "-   Digite 4 si desea hacer todas las anteriores                   -" << endl;
            cout << "--------------------------------------------------------------------" << endl;
            cin>>aa;
            switch (aa) {
                case 1:aux->modificaNombreProf();
                    break;

                case 2:aux->modificaApellidoIProf();
                    break;
                case 3:aux->modificaApellidoIIProf();
                    break;
                case 4:aux->modificaNombreProf();
                    aux->modificaApellidoIProf();
                    aux->modificaApellidoIIProf();
                default:
                    cout << "Error" << endl;
            }
        }
    }
    if (x == false) {
        cout << "Error no se pudo encontrar la escuela" << endl;
    }
}
//-----------------------------------------------------------------------------

void universidad::datosProf() {
    string a;
    bool x = false;
    cout << "-->Digite el nombre de la escuela donde se encuentra el Profesor<--" << endl;
    cin>>a;
    escuela* aux = NULL;
    ite = le->obtenerIterador();
    while (ite->masElementos()) {
        aux = ite->proximoElemento();
        if (aux->obtNombre() == a) {
            x = true;
            aux->informacionProf();
        }
    }
    if (x == false) {
        cout << "Error no se pudo encontrar la escuela" << endl;
    }
}
//-----------------------------------------------------------------------------

void universidad::verProf() {

    string a;
    bool x = false;
    cout << "-->Digite el nombre de la escuela a la que se le desea ver los profesores<--" << endl;
    cin>>a;
    escuela* aux = NULL;
    ite = le->obtenerIterador();
    while (ite->masElementos()) {
        aux = ite->proximoElemento();
        if (aux->obtNombre() == a) {
            x = true;
            aux->muestraProfes();
        }
    }
    if (x == false) {
        cout << "Error no se pudo encontrar la escuela" << endl;
    }
}
//-----------------------------------------------------------------------------

void universidad::asignaProfCurso() {

    string a;
    bool x = false;
    cout << "-->Digite el nombre de la escuela a la que pertenece el Profesor<--" << endl;
    cin>>a;
    escuela* aux = NULL;
    ite = le->obtenerIterador();
    while (ite->masElementos()) {
        aux = ite->proximoElemento();
        if (aux->obtNombre() == a) {
            x = true;
            aux->asigna();
        }
    }
    if (x == false) {
        cout << "Error no se pudo encontrar la escuela" << endl;
    }
}
//-----------------------------------------------------------------------------

void universidad::verProfYCur() {

    string a;
    bool x = false;
    cout << "-->Digite el nombre de la escuela a la que pertenece el Profesor<--" << endl;
    cin>>a;
    escuela* aux = NULL;
    ite = le->obtenerIterador();
    while (ite->masElementos()) {
        aux = ite->proximoElemento();
        if (aux->obtNombre() == a) {
            x = true;
            aux->muestraProfPorCur();
        }
    }
    if (x == false) {
        cout << "Error no se pudo encontrar la escuela" << endl;
    }
}

void universidad::deasignaProfCurso() {

    string a;
    bool x = false;
    cout << "-->Digite el nombre de la escuela a la que pertenece el Profesor<--" << endl;
    cin>>a;
    escuela* aux = NULL;
    ite = le->obtenerIterador();
    while (ite->masElementos()) {
        aux = ite->proximoElemento();
        if (aux->obtNombre() == a) {
            x = true;
            aux->desasigna();
        }
    }
    if (x == false) {
        cout << "Error no se pudo encontrar la escuela" << endl;
    }
}

void universidad::escuelaDirector() {

    string a;
    bool x = false;
    cout << "-->Digite el nombre de la escuela a la que pertenece el Profesor<--" << endl;
    cin>>a;
    escuela* aux = NULL;
    ite = le->obtenerIterador();
    while (ite->masElementos()) {
        aux = ite->proximoElemento();
        if (aux->obtNombre() == a) {
            x = true;
            aux->asignaDirector();
        }
    }
    if (x == false) {
        cout << "Error no se pudo encontrar la escuela" << endl;
    }
}

void universidad::soloProfYcur() {

    escuela* aux = NULL;
    ite = le->obtenerIterador();
    while (ite->masElementos()) {
        aux = ite->proximoElemento();
        aux->ambosPyC();

    }
}

void universidad::cargaAcademicaU() {

    string a;
    bool x = false;
    cout << "-->Digite el nombre de la escuela a la que pertenece el Profesor<--" << endl;
    cin>>a;
    escuela* aux = NULL;
    ite = le->obtenerIterador();
    while (ite->masElementos()) {
        aux = ite->proximoElemento();
        if (aux->obtNombre() == a) {
            x = true;
            aux->cargaAcademica();
        }
    }
    if (x == false) {
        cout << "Error no se pudo encontrar la escuela" << endl;
    }
}

void universidad::recuperarArcProf(string x,ifstream& entrada){
    //string a;
    //bool x = false;
    //cout << "-->Digite el nombre de la escuela donde se quieren recuperar los Profesores asignados<--" << endl;
    //cin>>a;
    escuela* aux = NULL;
    ite = le->obtenerIterador();
    while (ite->masElementos()) {
        aux = ite->proximoElemento();
        //if (aux->obtNombre() == a) {
          //  x = true;
        aux->recuperaProfA(x,entrada);
        //}
    }
    //if (x == false) {
        //cout << "Error no se pudo encontrar la escuela" << endl;
   // }
}

//-------------------------------------------------------------
void universidad::guardarArcProf(string x,ofstream& salida){
    escuela* aux = NULL;
    ite = le->obtenerIterador();
    while (ite->masElementos()) {
        aux = ite->proximoElemento();
        aux->guardaProfA(x,salida);  
    }
    
}
//---------------ESTUDIANTES--------------------------------------------------

void universidad::incluirEst() {
    string a, b, c, d, f;
    int beca;
    cout << "Digite el nombre del estudiante: " << endl;
    cin.ignore();
    getline(cin, a);
    cout << "Digite los apellidos del estudiante : " << endl;
    getline(cin, b);
    cout << "Digite la cedula del estudiante: " << endl;
    cin>>c;
    cout << "Digite el numero del carnet : " << endl;
    cin>>d;

    cout << "Digite la nacionalidad: " << endl;
    cin>>f;

    if (f == "Costarricense" || f == "costarricense" || f == "COSTARRICENSE") {
        cout << "La categoria de la beca solo puede ser un numero entre 1-10" << endl;
        cout << endl;
        cout << "Digite la categoria de la beca del estudiante: " << endl;
        cin>>beca;
        if (beca != 1 && beca != 2 && beca != 3 && beca != 4 && beca != 5 && beca != 6 && beca != 7 && beca != 8 && beca != 9 && beca != 10) {
            cout << "Error" << endl;
            cout << endl;
            cout << "Digite la categoria de la beca del estudiante: " << endl;
            cin>>beca;


        }
    } else {
        beca = 0;
    }

    est = new estudiante(a, b, c, d, f, beca);
    ls->agregarFinal(est);
}
//-----------------------------------------------------------------------------

void universidad::modificarEst() {
    int aa;
    cout << "--------------------------------------------------------------------" << endl;
    cout << "-   Digite 1 si desea modificar  el nombre del Estudiante          -" << endl;
    cout << "-   Digite 2 si desea modificar los apellidos del Estudiante       -" << endl;
    cout << "-   Digite 3 si desea modificar la nacionalidad del Estudiante     -" << endl;
    cout << "-   Digite 4 si desea hacer todas las anteriores                   -" << endl;
    cout << "--------------------------------------------------------------------" << endl;
    cin>>aa;
    switch (aa) {
        case 1:modNombreEst();
            break;

        case 2:modApellidosEst();
            break;
        case 3:modNacionalidadEst();
            break;
        case 4:modNombreEst();
            modApellidosEst();
            modNacionalidadEst();
            break;
        default:
            cout << "Error" << endl;
    }
}
//-----------------------------------------------------------------------------

void universidad::modNombreEst() {
    string a, b;
    bool x = false;
    cout << "->Digite el nombre del estudiante a modificar " << endl;
    cin.ignore();
    getline(cin, a);
    estudiante *aux = NULL;
    its = ls->obtenerIterador();
    while (its->masElementos()) {
        aux = its->proximoElemento();
        if (aux->obtenerNombre() == a) {
            x = true;
            cout << "->Digite el nuevo nombre del estudiante " << endl;
            cin>>b;
            aux->establecerNombre(b);
        }

    }
    if (x == false) {
        cout << "Error!!!, no se ha podido encontrar el estudiante" << endl;
    }

    /*est = new estudiante();
    est->establecerNombre(a);
    s->modNombre(est);*/

}
//-----------------------------------------------------------------------------

void universidad::modApellidosEst() {
    string a, b;
    bool x = false;
    cout << "->Digite los  apellidos del estudiante a modificar" << endl;
    cin.ignore();
    getline(cin, a);
    estudiante *aux = NULL;
    its = ls->obtenerIterador();
    while (its->masElementos()) {
        aux = its->proximoElemento();
        if (aux->obtenerApellidos() == a) {
            x = true;
            cout << "->Digite los nuevos apellido del estudiante " << endl;
            cin>>b;
            aux->establecerApellidos(b);
        }

    }
    if (x == false) {
        cout << "Error!!!, no se ha podido encontrar el estudiante" << endl;
    }
    /*est = new estudiante();
    est->establecerApellidos(a);
    s->modApellidos(est);*/
}
//-----------------------------------------------------------------------------

void universidad::modNacionalidadEst() {
    string a, b;
    bool x = false;
    //int beca;
    cout << "->Digite la nacionalidad del estudiante a modificar" << endl;
    cin.ignore();
    getline(cin, a);
    estudiante *aux = NULL;
    its = ls->obtenerIterador();
    while (its->masElementos()) {
        aux = its->proximoElemento();
        if (aux->obtenerNacionalidad() == a) {
            x = true;
            cout << "->Digite la nueva nacionalidad del estudiante " << endl;
            cin>>b;
            aux->establecerNacionalidad(b);
        }

    }
    if (x == false) {
        cout << "Error!!!, no se ha podido encontrar el estudiante" << endl;
    }
    /*est = new estudiante();
    est->establecerNacionalidad(a);
    s->modNacionalidad(est);*/
}
//-----------------------------------------------------------------------------

void universidad::buscarEstudiante() {
    int aa;
    cout << "---------------------------------------------------------------" << endl;
    cout << "-   Digite 1 si desea buscar al Estudiante por cedula         -" << endl;
    cout << "-   Digite 2 si desea buscar al Estudiante por carnet         -" << endl;
    cout << "---------------------------------------------------------------" << endl;
    cin>>aa;
    switch (aa) {
        case 1:buscarEstID();
            break;

        case 2:buscarEstCarnet();
            break;

        default:
            cout << "Error" << endl;
    }
}
//-----------------------------------------------------------------------------

void universidad::buscarEstID() {
    string a;
    bool x = false;
    cout << "Digite el numero de cedula del estudiante" << endl;
    cin>>a;
    estudiante *aux = NULL;
    its = ls->obtenerIterador();
    while (its->masElementos()) {
        aux = its->proximoElemento();
        if (aux->obtenerCedula() == a) {
            x = true;
            cout << aux->imprime();
        }
    }
    if (x == false) {
        cout << "Error!!!, no se ha podido encontrar el estudiante" << endl;
    }
    //est = new estudiante();
    //est->establecerCedula(a);

    //cout << s->buscar(est)->imprime();

}
//-----------------------------------------------------------------------------

void universidad::buscarEstCarnet() {
    string a;
    bool x = false;
    cout << "Digite el numero de carnet del estudiante" << endl;
    cin>>a;
    estudiante *aux = NULL;
    its = ls->obtenerIterador();
    while (its->masElementos()) {
        aux = its->proximoElemento();
        if (aux->obetenerCarnet() == a) {
            x = true;
            cout << aux->imprime();
        }
    }
    if (x == false) {
        cout << "Error!!!, no se ha podido encontrar el estudiante" << endl;
    }
    /*est = new estudiante();
    est->establecerCarnet(a);
    est = s->buscar(est);
    cout << est->imprime();*/

}
//-----------------------------------------------------------------------------

void universidad::matricular()//matricula a un estudiante a un curso buscando la escuela ala que pertenece el curso
{

    string a;
    bool x = false;
    cout << "Digite el nombre de la escuela " << endl;
    cin.ignore();
    getline(cin, a);
    escuela* aux = NULL;
    ite = le->obtenerIterador();
    while (ite->masElementos()) {
        aux = ite->proximoElemento();
        if (aux->obtNombre() == a) {
            x = true;
            aux->matricularEstu(ls);
        }
    }
    if (x == false) {
        cout << "Error no se pudo encontrar la escuela" << endl;
    }
    //--------------------------------------------------------------------------
    /* escuela *e2 = new escuela(a);
     e2 = (escuela*) k->buscar(e2);
     if (e2 != NULL) {
         //s=listaEstudiante

         e2->matricularEstu(s);
     } else {
         cout << "La escuela digitada no esta inscripta en la universidad!" << endl;
         matricular();
     }*/
}
//-----------------------------------------------------------------------------

void universidad::desasignarEst() {
    string a;
    bool x = false;
    cout << "Digite el nombre de la escuela " << endl;
    cin.ignore();
    getline(cin, a);
    escuela* aux = NULL;
    ite = le->obtenerIterador();
    while (ite->masElementos()) {
        aux = ite->proximoElemento();
        if (aux->obtNombre() == a) {
            x = true;
            curso*cur;
            cur = aux->retornaCur();
            cur->desasignaEst();
        }
    }
    if (x == false) {
        cout << "Error no se pudo encontrar la escuela" << endl;
    }

    /*escuela *e2 = new escuela(a);
    e2 = (escuela*) k->buscar(e2);
    if (e2 != NULL) {
        curso* cur;

        cur = (curso*) e2->retornaCur(); //retorna un curso de la lista de cursos que esta en escuela
        cur->desasignaEst(); // desasigna el estudiante al curso.
    } else {
        cout << "La escuela digitada no esta inscripta en la universidad!" << endl;
        desasignarEst();
    }*/
}

void universidad::mostrarEstYCurso() {
    string a;
    bool x = false;
    cout << "Digite el nombre de la escuela " << endl;
    cin.ignore();
    getline(cin, a);
    escuela* aux = NULL;
    ite = le->obtenerIterador();
    while (ite->masElementos()) {
        aux = ite->proximoElemento();
        if (aux->obtNombre() == a) {
            x = true;
            curso*cur;
            cur = aux->retornaCur();
            cur->mostrarEst();
        }
    }
    if (x == false) {
        cout << "Error no se pudo encontrar la escuela" << endl;
        mostrarEstYCurso();
    }

    /*escuela *e2 = new escuela(a);
    e2 = (escuela*) k->buscar(e2);
    if (e2 != NULL) {
        curso* cur;

        cur = (curso*) e2->retornaCur(); //retorna un curso de la lista de cursos que esta en escuela
        cur->mostrarEst(); // muestra todos los estudiantes matriculados en este curso 
    } else {
        cout << "La escuela digitada no esta inscripta en la universidad!" << endl;
        mostrarEstYCurso();
    }*/

}

void universidad::mostrarCursosEstudiante() {
    string a;
    bool x = false;
    cout << "Digite la cedula del estudiante" << endl;
    cin>>a;
    cout << endl;
    estudiante* aux = NULL;
    its = ls->obtenerIterador();
    while (its->masElementos()) {
        aux = its->proximoElemento();
        if (aux->obtenerCedula() == a) {
            x = true;
            cout << "Lista de cursos matriculados" << endl;
            cout << endl;
            escuela* aux2 = NULL;
            ite = le->obtenerIterador();
            while (ite->masElementos()) {
                aux2 = ite->proximoElemento();
                aux2->imprimirCursoPorEstudiante(aux);
            }

        }
    }
    if (x == false) {
        cout << "Error no se pudo encontrar la escuela" << endl;
    }

    /*
    est = new estudiante();
    est->establecerCedula(a);
    est = s->buscar(est); //ley de demeter
    if (est != NULL) {
        cout << "Lista de cursos matriculados" << endl;
        cout << endl;
        k->totalCursoEst(est);
    } else {
        cout << "Error!!" << endl;
        cout << "El estudiante digitado no se encuentra inscripto en la universidad!" << endl;
        mostrarCursosEstudiante();
    }*/
}

void universidad::costoMatricula() {
    string a;
    bool x = false;
    cout << "Digite la cedula del estudiante" << endl;
    cin>>a;
    cout << endl;
    estudiante* aux = NULL;
    its = ls->obtenerIterador();
    while (its->masElementos()) {
        aux = its->proximoElemento();
        if (aux->obtenerCedula() == a) {
            x = true;
            m = new matricula(est, le);
            cout << "El monto total a pagar por los cursos matrculados es: " << endl;
            cout << m->tipoBeca();


        }
    }
    if (x == false) {
        cout << "Error no se pudo encontrar el estudiante" << endl;
        mostrarCursosEstudiante();
    }
    /*
    est = new estudiante();
    est->establecerCedula(a);
    est = s->buscar(est); //ley de demeter
    if (est != NULL) {
        m = new matricula(est, k);
        cout << "El monto total a pagar por los cursos matrculados es: " << endl;
        cout << m->tipoBeca();
    } else {
        cout << "Error!!" << endl;
        cout << "El estudiante digitado no se encuentra inscripto en la universidad!" << endl;
        mostrarCursosEstudiante();
    } */
}
//----------------Ley de 3------------------------------------

universidad::universidad(const universidad &ca) {
    le = ca.le;
    ite = ca.ite;
    this->nombre = ca.nombre;
    this->direccion = ca.direccion;
    this->telefono = ca.telefono;
}
//-----------------------------------------------------------

universidad::~universidad() {

}
//----------------------------------------------------------

universidad& universidad::operator=(const universidad &ca) {
    if (this != &ca) {
        le = ca.le;
        ite = ca.ite;
        this->nombre = ca.nombre;
        this->direccion = ca.direccion;
        this->telefono = ca.telefono;
    }
    return *this;
}
//metodos relacionados con archivos 

universidad::universidad(ifstream& entrada) {
    deserialize(entrada, this);
}

void universidad::deserialize(ifstream& entrada, universidad* u) {
    u->nombre = sstring::deserialize(entrada);
    u->direccion = sstring::deserialize(entrada);
    entrada.read((char*) &u->telefono, sizeof (u->telefono));
    u->le = new listaEscuela(entrada);
    u->ls = new listaEstudiante(entrada);
    if (!entrada.good())
        throw -1;
}

bool universidad::serialize(ofstream& salida, universidad* u) {
    sstring::serialize(salida, u->nombre);
    sstring::serialize(salida, u->direccion);
    salida.write((char*) &u->telefono, sizeof (u->telefono));
    u->le->guardar(salida);
    u->ls->guardar(salida);
    return salida.good();
}

bool universidad::guardar(ofstream& salida) {
    serialize(salida, (universidad*)this);
}