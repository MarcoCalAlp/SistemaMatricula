/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   estudiante.h
 * Author: Johan
 *
 * Created on 1 de mayo de 2017, 08:35 PM
 */

#ifndef ESTUDIANTE_H
#define ESTUDIANTE_H

#include "sstring.h"
#include "std.h"
class estudiante {
public:
    estudiante(string,string,string,string,string,int);
    estudiante();
    int obtenerPorcentaje();
    string obtenerNombre();
    string obtenerCedula();
    string obetenerCarnet();
    string obtenerApellidos();
    string obtenerNacionalidad();
    void establecerNombre(string);
    void establecerApellidos(string);
    void establecerNacionalidad(string);
    void establecerCedula(string);
    void establecerPcBeca(int);
    void establecerCarnet(string);
    virtual string imprime();
    virtual ~estudiante();
    //meotodos relacionados con archivos 
    estudiante(ifstream&);
    virtual bool  guardar(ofstream&);
    static void deserialize(ifstream&,estudiante*);
    static bool serialize(ofstream&, estudiante*);
private:
    string nombre;
    string cedula;
    string carnet;
    string apellidos;
    string nacionalidad;
  int porcentaje;

   
    
};

#endif /* ESTUDIANTE_H */

