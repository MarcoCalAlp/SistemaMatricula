
#ifndef LISTA_H
#define	LISTA_H

#include "std.h"
#include "iteradorLista.h"
#include "nodo.h"
#include "sstring.h"

template <class T>
class lista{
public:
    lista();
   // lista( lista& orig);
    virtual ~lista();

    virtual bool vacio() const;
    virtual int numElementos() const;
    virtual void agregar(T*);
    virtual void eliminar(T*);
    virtual void agregarInicio(T*);
    virtual void agregarFinal(T*);
    virtual iterador<T>* obtenerIterador() const;
    virtual int totalObjetos()const;
 

private:
    nodo<T>* primerNodo;
    nodo<T>* ultimoNodo;
    int k;

};
template<class T>
lista<T>::lista() {
    primerNodo = NULL;
    ultimoNodo = NULL;
    k = 0;
}
template<class T>
lista<T>::~lista() {
}
template<class T>
bool lista<T>::vacio() const {
    return primerNodo == NULL;
}
template<class T>
int lista<T>::numElementos() const {
    return k;
}
template<class T>
void lista<T>::agregar(T* nuevaInfo) {

    // Cuando se agrega un elemento a una lista
    // que está inicialmente vacía, hay que fijar
    // el apuntador al último nodo.

    bool iniciandoLista = vacio();

    primerNodo = new nodo<T>(nuevaInfo, primerNodo);
    if (iniciandoLista) {
        ultimoNodo = primerNodo;
    }
    k++;
}
template<class T>
void lista<T>::eliminar(T*eli)
{
        nodo<T> * borrar = NULL;
	nodo<T> * aux = primerNodo;
        T*inf=primerNodo->obtenerInfo();
       // profesor*pr=((profesor*)primero->getV());

	if (primerNodo != NULL &&inf == eli) {
		borrar = primerNodo;
		primerNodo = primerNodo->obtenerSiguiente();
	}
	else {
		while (aux->obtenerSiguiente() != NULL) {
                    nodo<T> *aux2=aux->obtenerSiguiente();
                     T*inf2=aux2->obtenerInfo();
                    //profesor*pr2=((profesor*)aux2->getV());
                    if (inf2 == eli) {
				borrar = aux->obtenerSiguiente();
				aux->fijarSiguiente(borrar->obtenerSiguiente());
				break;
			}
			aux = aux->obtenerSiguiente();
		}
	}
	if (borrar != NULL) {
		borrar->fijarSiguiente(NULL);
	}
}
template<class T>
void lista<T>::agregarInicio(T* nuevaInfo) {
    agregar(nuevaInfo);
}
template<class T>
void lista<T>::agregarFinal(T* nuevaInfo) {
    if (!vacio()) {

        // Si la lista no está vacía, la operación no afecta
        // al primer nodo, pero se debe actualizar el apuntador
        // al último nodo.

        ultimoNodo->fijarSiguiente(new nodo<T>(nuevaInfo, NULL));
        ultimoNodo = ultimoNodo->obtenerSiguiente();
        k++;

    } else {

        // Si la lista está vacía, agregar al inicio o
        // al final es la misma operación.

        agregar(nuevaInfo);
    }
}
template<class T>
iterador<T>* lista<T>::obtenerIterador() const{
    return new iteradorLista<T>(primerNodo);
}
template<class T>
int lista<T>::totalObjetos() const{
	int can = 0;
        iterador<T>* i = this->obtenerIterador();
	
	while(i->masElementos()) {

		T* objeto= (T*)i->proximoElemento();

		if (objeto != NULL){
			can++;
		}
             
	}
	return can;
}

#endif	/* LISTA_H */

