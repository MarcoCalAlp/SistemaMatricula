/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   listaEscuela.h
 * Author: Johan
 *
 * Created on 15 de junio de 2017, 12:59 AM
 */

#ifndef LISTAESCUELA_H
#define LISTAESCUELA_H
#include "lista.h"
#include "std.h"
#include "escuela.h"
#include<sstream>
using namespace std;
class listaEscuela:public lista<escuela> {
public:
    listaEscuela();
    virtual ~listaEscuela();
     //metodos relacionados con archivos 
      listaEscuela(ifstream&);
    virtual bool guardar(ofstream&);
    static void deserialize(ifstream&,  listaEscuela*);
    static bool serialize(ofstream&,  listaEscuela*);
   virtual  int totalObjetos()const;
   string toString();
private:

};

#endif /* LISTAESCUELA_H */

