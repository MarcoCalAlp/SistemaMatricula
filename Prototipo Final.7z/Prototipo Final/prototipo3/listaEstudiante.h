/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   listaEstudiante.h
 * Author: Johan
 *
 * Created on 15 de junio de 2017, 12:26 AM
 */

#ifndef LISTAESTUDIANTE_H
#define LISTAESTUDIANTE_H
#include "lista.h"
#include "std.h"
#include "estudiante.h"
#include<sstream>
using namespace std;
class listaEstudiante:public lista<estudiante> {
public:
    listaEstudiante();
    virtual ~listaEstudiante();
//metodos relacionados con archivos 
       listaEstudiante(ifstream&);
    virtual bool guardar(ofstream&);
    static void deserialize(ifstream&,   listaEstudiante*);
    static bool serialize(ofstream&,   listaEstudiante*);
   virtual  int totalObjetos()const;
   string toString();
};

#endif /* LISTAESTUDIANTE_H */

