/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   matricula.h
 * Author: Johan
 *
 * Created on 12 de mayo de 2017, 10:10 PM
 */

#ifndef MATRICULA_H
#define MATRICULA_H
#include "listaEscuela.h"

#include "estudiante.h"

class matricula {
public:
    matricula(estudiante*, listaEscuela *);
    int tipoBeca();
    virtual ~matricula();
    
private:
   // listaEscuelas* escuelas;
    listaEscuela* escuelas;
    estudiante *est;
    
};

#endif /* MATRICULA_H */

