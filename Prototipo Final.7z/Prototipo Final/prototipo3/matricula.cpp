/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   matricula.cpp
 * Author: Johan
 * 
 * Created on 12 de mayo de 2017, 10:10 PM
 */

#include "matricula.h"

matricula::matricula(estudiante* e, listaEscuela *s) {
    escuelas=s;
    est=e;
}
int matricula::tipoBeca()
{
    int total=0;
    //int y=0;
    int precioFinal=0;
    int precio=0;
    int recarga=0;
    if(est->obtenerNacionalidad()=="Costarricense"||est->obtenerNacionalidad()=="costarricense"||est->obtenerNacionalidad()=="COSTARRICENSE")
    {
        escuela* aux = NULL;
        iterador<escuela> * i = escuelas->obtenerIterador();
         while(i->masElementos())
        {
             aux = i->proximoElemento();
             total= total+aux->totalCreditosCurso(est);
        }
        //total=escuelas->totalCreditosCurso();
        if(est->obtenerPorcentaje()==1)
        {
           precio=(total*10000)+15000; 
           precioFinal=precio-precio*0.10;
        }
         if(est->obtenerPorcentaje()==2)
        {
           precio=(total*10000)+15000; 
           precioFinal=precio-precio*0.20;
        }
         if(est->obtenerPorcentaje()==3)
        {
           precio=(total*10000)+15000; 
           precioFinal=precio-precio*0.30;
        }
         if(est->obtenerPorcentaje()==4)
        {
           precio=(total*10000)+15000; 
           precioFinal=precio-precio*0.40;
        }
         if(est->obtenerPorcentaje()==5)
        {
           precio=(total*10000)+15000; 
           precioFinal=precio-precio*0.50;
        }
         if(est->obtenerPorcentaje()==6)
        {
           precio=(total*10000)+15000; 
           precioFinal=precio-precio*0.60;
        }
         if(est->obtenerPorcentaje()==7)
        {
           precio=(total*10000)+15000; 
           precioFinal=precio-precio*0.70;
        }
         if(est->obtenerPorcentaje()==8)
        {
           precio=(total*10000)+15000; 
           precioFinal=precio-precio*0.80;
        }
         if(est->obtenerPorcentaje()==9)
        {
           precio=(total*10000)+15000; 
           precioFinal=precio-precio*0.90;
        }
         if(est->obtenerPorcentaje()==10)
        {
          
           precioFinal=15000;
        }
        return precioFinal;
        
    }
    else{
        precio= precio=(total*10000)+15000; 
        precioFinal=precio+precio*0.40;
        return precioFinal;
    }
    
}
matricula::~matricula() { 
}

