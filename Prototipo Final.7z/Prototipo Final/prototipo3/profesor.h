/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   profesor.h
 * Author: Johan
 *
 * Created on 1 de mayo de 2017, 08:34 PM
 */

#ifndef PROFESOR_H
#define PROFESOR_H

#include "sstring.h"

class profesor{
public:
    profesor(string,string,string,string);
    profesor(profesor&);
  
    profesor();
    string obtenerNombre();
    string obtenerCedula();
    string obtenerApellido1();
   string obtenerApellido2();
   void establecerNombre(string);
   void establecerApellido1(string);
   void establecerApellido2(string);
   void establecerCedula(string);
   virtual string imprime();
    virtual ~profesor();
    
    //metodos relacionados con archivos 
      profesor(ifstream&);
    virtual bool guardar(ofstream&);
    static void deserialize(ifstream&, profesor*);
    static bool serialize(ofstream&, profesor*);
private:
    string nombre;
    string cedula;
    string apellido1;
    string apellido2;
};

#endif /* PROFESOR_H */

